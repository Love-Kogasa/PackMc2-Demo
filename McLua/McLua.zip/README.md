# LuaComputer
本Addon尝试为Mc增加了Lua控制台.  
测试用版本1.20.30.  
实际上你应该将addon依赖库版本更改为你的mc版本的最新beta版本.  
以及你应该解压zip，然后运行demo，因为bify打包的一些特殊原因，我对lua.js做了一些小改动.  
依赖的pack-mc-2版本不要从npm获取，直接从gh获取替换(gh是最新版).  
Tip: 你应该长按方块打开界面，这是由微软命名不规范引起的

# LuaComputer
*The following content is translated from the previous text*

This Addon attempts to add a Lua console to Mc

Test version 1.20.30

Actually, you should change the addon dependency library version to the latest beta version of your MC version

And you should unzip the zip file and run the demo. Due to some special reasons for bify packaging, I made some minor changes to lua.js

Do not obtain the dependent pack-mc-2 version from npm, directly obtain the replacement from gh (gh is the latest version)

Tip: You should long press the block to open the interface, which is caused by Microsoft's naming conventions(