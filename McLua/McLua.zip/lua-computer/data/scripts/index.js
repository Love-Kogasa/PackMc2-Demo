import * as $server from '@minecraft/server'
import * as $server_ui from '@minecraft/server-ui'
var __dirname = ''
var __filename = 'index.js';
var $_vfs = {
  "stdlib.lua": "-- base lib\r\n\r\nfunction assert(v, msg)\r\n    if (not v) then\r\n        error(msg or \"Assertion failed!\")\r\n    end\r\nend\r\n\r\nfunction collectgarbage()\r\n    -- do nothing.\r\nend\r\n\r\nlocal function notImplemented(fn)\r\n    error(\"Not implemented\")\r\nend\r\n\r\ndofile = notImplemented\r\n\r\nerror = __js [[ \r\nfunction(val){\r\n    if (typeof(val) =='string')\r\n        throw new Error(val);\r\n    throw val;\r\n}\r\n]];\r\n\r\ngetmetatable = __js [[ \r\nfunction(val){\r\n    return val && val.metatable;\r\n}\r\n]]\r\n\r\nfunction ipairs(t)\r\n    return function(t, i)\r\n        if (i >= #t) then\r\n            return\r\n        end\r\n        return i+1, t[i+1]\r\n    end, t, 0\r\nend\r\n\r\nloadString = __js [[\r\nfunction(str, env){\r\n    return l.__loadString(str, env);\r\n}\r\n]]\r\n\r\nfunction load(ld,source,mod,env)\r\n    if (type(ld) == 'function') then\r\n        local chunks = {};\r\n        for v in ld do\r\n            table.insert(chunk, v)\r\n        end\r\n        ld = table.concat(chunks)\r\n    end\r\n    return loadString(ld, env)\r\nend\r\n\r\nloadfile = notImplemented\r\n\r\nnext = __js[[\r\nl._f(function(t, k){\r\n    if (! (t instanceof l.LuaTable)) {\r\n        return [];\r\n    }\r\n    k = t.nextKey(k);\r\n    if (k === null){\r\n        return [];\r\n    }\r\n    return [k, t.get(k)];\r\n})\r\n]]\r\n\r\npairs = function (t)\r\n    return next, t, nil\r\nend\r\n\r\npcall = __js[[\r\nl._f(function (f){\r\n    var args = Array.prototype.slice.call(arguments, 1);\r\n    try{\r\n        var ret = l.__call(f, args);\r\n        ret.unshift(true);\r\n        return ret;\r\n    } catch(e){\r\n        return [false, e];\r\n    }\r\n})\r\n]]\r\n\r\nfunction print(...)\r\n    local args = {...}\r\n    for i = 1, #args do\r\n        args[i] = tostring(args[i])\r\n    end\r\n    io.write(table.concat(args, \" \"))\r\n    io.write(\"\\n\")\r\nend\r\n\r\nrawequal = __js[[\r\nfunction (a, b){\r\n    return a === b;\r\n}\r\n]]\r\n\r\nrawget = __js[[\r\nfunction (t, k){\r\n    var tp = l.__type(t);\r\n    if (tp != 'table') {\r\n        throw Error(\"rawget called with type \" + tp);\r\n    }\r\n    return t.get(k);\r\n}\r\n]]\r\n\r\nrawlen = __js[[\r\nfunction (t){\r\n    var tp = l.__type(t);\r\n    if (tp != 'table') {\r\n        throw Error(\"rawlen called with type \" + tp);\r\n    }\r\n    return t.length();\r\n}\r\n]]\r\n\r\nrawset = __js[[\r\nfunction (t, k, v){\r\n    var tp = l.__type(t);\r\n    if (tp != 'table') {\r\n        throw Error(\"rawget called with type \" + tp);\r\n    }\r\n    t.set(k, v);\r\n    return t;\r\n}\r\n]]\r\n\r\nselect = __js[[\r\nfunction (index){\r\n    if (index == '#') {\r\n        return arguments.length;\r\n    }\r\n    return arguments[index];\r\n}\r\n]]\r\n\r\nsetmetatable = __js [[ \r\nfunction(val, mt){\r\n    if (typeof(val) != \"object\") {\r\n        throw new Error(\"Cannot set metatable to non-object values.\");\r\n    }\r\n    val.metatable = mt;\r\n    return val;\r\n}\r\n]]\r\n\r\ntonumber = __js \"l.__tonumber\"\r\ntostring = __js \"l.__tostring\"\r\ntype = __js \"l.__type\"\r\n\r\nxpcall = __js[[\r\nfunction (f, msgh){\r\n    var args = Array.prototype.slice.call(arguments, 2);\r\n    try{\r\n        return l.__call(f, args);\r\n    } catch(e){\r\n        return l.__call(msgh, [e]);\r\n    }\r\n}\r\n]]\r\n\r\npackage = {}\r\n\r\npackage.loaded = {}\r\npackage.preload = {}\r\n\r\nfunction require(modname)\r\n    local mod = package.loaded[modname]\r\n    if (mod) then\r\n        return mod\r\n    end\r\n\r\n    local func, extra\r\n    for i,v in ipairs(package.searchers) do\r\n        func, extra = v(modname)\r\n        if (func) then\r\n            break;\r\n        end\r\n    end\r\n    local ret = func(modname, extra)\r\n    package.loaded[modname] = package.loaded[modname] or ret\r\n    return package.loaded[modname]\r\nend\r\n\r\nstring = {}\r\n__js \"l.stringMT\" = string\r\nstring.byte = __js [[\r\nl._f(function (s, i, j){\r\n    if (typeof(s) != 'string'){\r\n        s = l.__tostring(s);\r\n        if (s == l.ds){\r\n            // Empty string.\r\n            return [];\r\n        }\r\n    }\r\n    i = i || 1;\r\n    j = j || i;\r\n    if (i < 0){\r\n        i = s.length + i;\r\n    } else {\r\n        i--;\r\n    }\r\n    if (j < 0){\r\n        j = s.length + j + 1;\r\n    }\r\n    var ret = []; \r\n    for (; i<j; ++i){\r\n        var c = s.charCodeAt(i);\r\n        if (c){\r\n            ret.push(c);\r\n        }\r\n    }\r\n    return ret;\r\n})\r\n]]\r\n\r\nstring.dump = __js \"l.__dump\"\r\n\r\n\r\nstring.find = __js[[\r\nfunction (s, pattern, init, plain){\r\n    if (plain){\r\n        return s.indexOf(pattern, init && (init-1))+1\r\n    }\r\n    throw new Error(\"Not implemented.\")\r\n}\r\n]]\r\n\r\nstring.len = __js[[\r\nfunction (s){\r\n    if (typeof(s) != 'string' && s != l.ds){\r\n        s = l.__tostring(s);\r\n    }\r\n    if (s == l.ds){\r\n        // Empty string.\r\n        return 0;\r\n    }\r\n    return s.length;\r\n}\r\n]]\r\n\r\nstring.lower = __js[[\r\nfunction (s){\r\n    if (typeof(s) != 'string' && s != l.ds){\r\n        s = l.__tostring(s);\r\n    }\r\n    if (s == l.ds){\r\n        // Empty string.\r\n        return s;\r\n    }\r\n    return s.toLowerCase();\r\n}\r\n]]\r\n\r\nstring.upper = __js[[\r\nfunction (s){\r\n    if (typeof(s) != 'string' && s != l.ds){\r\n        s = l.__tostring(s);\r\n    }\r\n    if (s == l.ds){\r\n        // Empty string.\r\n        return s;\r\n    }\r\n    return s.toUpperCase();\r\n}\r\n]]\r\n\r\nstring.rep = __js[[\r\nfunction (s, n, sep){\r\n    if (sep){\r\n        return new Array(n).join(s+sep) + s;\r\n    } else {\r\n        return new Array(n+1).join(s);\r\n    }\r\n}\r\n]]\r\n\r\nstring.reverse = __js[[\r\nfunction (s){\r\n    if (typeof(s) != 'string' && s != l.ds){\r\n        s = l.__tostring(s);\r\n    }\r\n    if (s == l.ds){\r\n        // Empty string.\r\n        return s;\r\n    }        \r\n    return s.split(\"\").reverse().join(\"\")\r\n}\r\n]]\r\n\r\nstring.sub = __js[[\r\nfunction (s, i, j){\r\n    if (typeof(s) != 'string' && s != l.ds){\r\n        s = l.__tostring(s);\r\n    }\r\n    if (s == l.ds){\r\n        // Empty string.\r\n        return [s];\r\n    }        \r\n    j = j || s.length;\r\n    if (i < 0){\r\n        i = s.length + i;\r\n    } else {\r\n        i--;\r\n    }\r\n    if (j < 0){\r\n        j = s.length + j + 1;\r\n    }\r\n    return s.substring(s, i, j);\r\n}\r\n]]\r\n\r\ntable = {}\r\n\r\ntable.concat = __js [[\r\nfunction (list, sep, i, j){\r\n    list = list.array;\r\n    if (i){\r\n        if (j){\r\n            list = list.slice(i-1, j-1);\r\n        } else {\r\n            list = list.slice(i-1);\r\n        }\r\n    }\r\n    return list.join(sep || \"\")\r\n}\r\n]]\r\n\r\ntable.insert = __js [[\r\nfunction (t, pos, value){\r\n    if (value){\r\n        t.array.splice(pos-1, 0, value);\r\n    } else {\r\n        t.array.push(pos);\r\n    }\r\n}\r\n]]\r\n\r\ntable.pack = function(...)\r\n    return {...}\r\nend\r\npack = table.pack\r\n\r\ntable.remove = __js[[\r\nl._f(function (t, pos){\r\n    if (pos){\r\n        return t.array.splice(pos-1, 1);\r\n    } else {\r\n        return [t.array.pop()];\r\n    }\r\n})\r\n]]\r\n\r\ntable.sort = __js[[\r\nfunction (t, comp){\r\n    if (comp){\r\n        t.array.sort(function(a, b){\r\n            if (comp(a, b)[0]){\r\n                return -1;\r\n            } else if (comp(b, a)[0]){\r\n                return 1;\r\n            }\r\n            return 0;\r\n        })\r\n    } else {\r\n        t.array.sort(function(a, b){\r\n            if (l.__lt(a, b)){\r\n                return -1;\r\n            } else if (l.__lt(b, a)){\r\n                return 1;\r\n            }\r\n            return 0;\r\n        });\r\n    }\r\n}\r\n]]\r\n\r\ntable.unpack = __js[[\r\nl._f(function (t){\r\n    return t.array;\r\n})\r\n]]\r\n\r\nmath = {}\r\n\r\nmath.abs = __js \"Math.abs\"\r\nmath.acos = __js \"Math.acos\"\r\nmath.asin = __js \"Math.asin\"\r\nmath.atan = __js \"Math.atan\"\r\nmath.atan2 = __js \"Math.atan2\"\r\nmath.ceil = __js \"Math.ceil\"\r\nmath.cos = __js \"Math.cos\"\r\nmath.cosh = __js \"Math.cosh\"\r\nmath.deg = __js \"Math.deg\"\r\nmath.exp = __js \"Math.exp\"\r\nmath.floor = __js \"Math.floor\"\r\nmath.pow = __js \"Math.pow\"\r\nmath.sin = __js \"Math.sin\"\r\nmath.sinh = __js \"Math.sinh\"\r\nmath.sqrt = __js \"Math.sqrt\"\r\nmath.tan = __js \"Math.tan\"\r\nmath.tanh = __js \"Math.tanh\"\r\nmath.pi = __js [[Math.PI]]\r\n\r\n\r\nmath.log = __js [[\r\nfunction (v, base){\r\n    return base ? Math.log(v)/Math.log(base) : Math.log(v);\r\n}\r\n]]\r\n\r\nmath.max = __js [[\r\nfunction (){\r\n    return Math.max.apply(null, arguments);\r\n}\r\n]]\r\n\r\nmath.min = __js [[\r\nfunction (v){\r\n    return Math.min.apply(null, arguments);\r\n}\r\n]]\r\n\r\nmath.rad = __js [[\r\n    function (v){\r\n        return [v*Math.PI/180];\r\n    }\r\n]]\r\n\r\nmath.random = __js[[\r\n    function  (m, n){\r\n        if (m){\r\n            if (!n){\r\n                return [Math.floor(Math.random()*m)+1]\r\n            }\r\n            return [Math.floor(Math.random()*(n-m+1))+m]\r\n        }\r\n        return [Math.random()];\r\n    }\r\n]]\r\n\r\nbit32 = {}\r\n\r\nbit32.arshift = __js[[\r\n    function (x, disp){\r\n        return x<<disp;\r\n    }\r\n]]\r\n\r\nbit32.band = __js[[\r\n    function (x){\r\n        for (var i= 1; i < arguments.length; i++){\r\n            x &= arguments[i];\r\n        }\r\n        return x;\r\n    }\r\n]]\r\n\r\nbit32.bnot = __js[[\r\n    function (x){\r\n        return ~x;\r\n    }\r\n]]\r\n\r\nbit32.bor = __js[[\r\n    function (x){\r\n        for (var i= 1; i < arguments.length; i++){\r\n            x |= arguments[i];\r\n        }\r\n        return x;\r\n    }\r\n]]\r\n\r\nbit32.btest = __js[[\r\n    function (x){\r\n        for (var i= 1; i < arguments.length; i++){\r\n            x &= arguments[i];\r\n        }\r\n        return x != 0;\r\n    }\r\n]]\r\n\r\nbit32.bxor = __js[[\r\n    function (x){\r\n        for (var i= 1; i < arguments.length; i++){\r\n            x ^= arguments[i];\r\n        }\r\n        return x != 0;\r\n    }\r\n]]\r\n\r\n\r\nio = {}\r\n\r\nio.write = __js[[\r\nfunction (v){\r\n    if (v != \"\\n\"){\r\n        console.log(v)\r\n    }\r\n}\r\n]]\r\n\r\nfunction io.flush()\r\nend\r\n\r\nos = {}\r\n\r\nos.clock = __js[[\r\n    (function(){\r\n        var start = Date.now();\r\n        return function(){\r\n            return (Date.now() - start)/1000;\r\n        }\r\n    })()\r\n]]\r\n\r\nfunction os.difftime(t2, t1)\r\n    return t2 - t1;\r\nend\r\n\r\nos.time = __js [[\r\nfunction(){\r\n    return Date.now()/1000;\r\n}\r\n]]\r\n"
};(function(){function r(e,n,t){function o(i,f){if(!n[i]){if(!e[i]){var c="function"==typeof require&&require;if(!f&&c)return c(i,!0);if(u)return u(i,!0);var a=new Error("Cannot find module '"+i+"'");throw a.code="MODULE_NOT_FOUND",a}var p=n[i]={exports:{}};e[i][0].call(p.exports,function(r){var n=e[i][1][r];return o(n||r)},p,p.exports,r,e,n,t)}return n[i].exports}for(var u="function"==typeof require&&require,i=0;i<t.length;i++)o(t[i]);return o}return r})()({1:[function(require,module,exports){

},{}],2:[function(require,module,exports){
(function (process){(function (){
// 'path' module extracted from Node.js v8.11.1 (only the posix part)
// transplited with Babel

// Copyright Joyent, Inc. and other Node contributors.
//
// Permission is hereby granted, free of charge, to any person obtaining a
// copy of this software and associated documentation files (the
// "Software"), to deal in the Software without restriction, including
// without limitation the rights to use, copy, modify, merge, publish,
// distribute, sublicense, and/or sell copies of the Software, and to permit
// persons to whom the Software is furnished to do so, subject to the
// following conditions:
//
// The above copyright notice and this permission notice shall be included
// in all copies or substantial portions of the Software.
//
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS
// OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
// MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN
// NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM,
// DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR
// OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE
// USE OR OTHER DEALINGS IN THE SOFTWARE.

'use strict';

function assertPath(path) {
  if (typeof path !== 'string') {
    throw new TypeError('Path must be a string. Received ' + JSON.stringify(path));
  }
}

// Resolves . and .. elements in a path with directory names
function normalizeStringPosix(path, allowAboveRoot) {
  var res = '';
  var lastSegmentLength = 0;
  var lastSlash = -1;
  var dots = 0;
  var code;
  for (var i = 0; i <= path.length; ++i) {
    if (i < path.length)
      code = path.charCodeAt(i);
    else if (code === 47 /*/*/)
      break;
    else
      code = 47 /*/*/;
    if (code === 47 /*/*/) {
      if (lastSlash === i - 1 || dots === 1) {
        // NOOP
      } else if (lastSlash !== i - 1 && dots === 2) {
        if (res.length < 2 || lastSegmentLength !== 2 || res.charCodeAt(res.length - 1) !== 46 /*.*/ || res.charCodeAt(res.length - 2) !== 46 /*.*/) {
          if (res.length > 2) {
            var lastSlashIndex = res.lastIndexOf('/');
            if (lastSlashIndex !== res.length - 1) {
              if (lastSlashIndex === -1) {
                res = '';
                lastSegmentLength = 0;
              } else {
                res = res.slice(0, lastSlashIndex);
                lastSegmentLength = res.length - 1 - res.lastIndexOf('/');
              }
              lastSlash = i;
              dots = 0;
              continue;
            }
          } else if (res.length === 2 || res.length === 1) {
            res = '';
            lastSegmentLength = 0;
            lastSlash = i;
            dots = 0;
            continue;
          }
        }
        if (allowAboveRoot) {
          if (res.length > 0)
            res += '/..';
          else
            res = '..';
          lastSegmentLength = 2;
        }
      } else {
        if (res.length > 0)
          res += '/' + path.slice(lastSlash + 1, i);
        else
          res = path.slice(lastSlash + 1, i);
        lastSegmentLength = i - lastSlash - 1;
      }
      lastSlash = i;
      dots = 0;
    } else if (code === 46 /*.*/ && dots !== -1) {
      ++dots;
    } else {
      dots = -1;
    }
  }
  return res;
}

function _format(sep, pathObject) {
  var dir = pathObject.dir || pathObject.root;
  var base = pathObject.base || (pathObject.name || '') + (pathObject.ext || '');
  if (!dir) {
    return base;
  }
  if (dir === pathObject.root) {
    return dir + base;
  }
  return dir + sep + base;
}

var posix = {
  // path.resolve([from ...], to)
  resolve: function resolve() {
    var resolvedPath = '';
    var resolvedAbsolute = false;
    var cwd;

    for (var i = arguments.length - 1; i >= -1 && !resolvedAbsolute; i--) {
      var path;
      if (i >= 0)
        path = arguments[i];
      else {
        if (cwd === undefined)
          cwd = process.cwd();
        path = cwd;
      }

      assertPath(path);

      // Skip empty entries
      if (path.length === 0) {
        continue;
      }

      resolvedPath = path + '/' + resolvedPath;
      resolvedAbsolute = path.charCodeAt(0) === 47 /*/*/;
    }

    // At this point the path should be resolved to a full absolute path, but
    // handle relative paths to be safe (might happen when process.cwd() fails)

    // Normalize the path
    resolvedPath = normalizeStringPosix(resolvedPath, !resolvedAbsolute);

    if (resolvedAbsolute) {
      if (resolvedPath.length > 0)
        return '/' + resolvedPath;
      else
        return '/';
    } else if (resolvedPath.length > 0) {
      return resolvedPath;
    } else {
      return '.';
    }
  },

  normalize: function normalize(path) {
    assertPath(path);

    if (path.length === 0) return '.';

    var isAbsolute = path.charCodeAt(0) === 47 /*/*/;
    var trailingSeparator = path.charCodeAt(path.length - 1) === 47 /*/*/;

    // Normalize the path
    path = normalizeStringPosix(path, !isAbsolute);

    if (path.length === 0 && !isAbsolute) path = '.';
    if (path.length > 0 && trailingSeparator) path += '/';

    if (isAbsolute) return '/' + path;
    return path;
  },

  isAbsolute: function isAbsolute(path) {
    assertPath(path);
    return path.length > 0 && path.charCodeAt(0) === 47 /*/*/;
  },

  join: function join() {
    if (arguments.length === 0)
      return '.';
    var joined;
    for (var i = 0; i < arguments.length; ++i) {
      var arg = arguments[i];
      assertPath(arg);
      if (arg.length > 0) {
        if (joined === undefined)
          joined = arg;
        else
          joined += '/' + arg;
      }
    }
    if (joined === undefined)
      return '.';
    return posix.normalize(joined);
  },

  relative: function relative(from, to) {
    assertPath(from);
    assertPath(to);

    if (from === to) return '';

    from = posix.resolve(from);
    to = posix.resolve(to);

    if (from === to) return '';

    // Trim any leading backslashes
    var fromStart = 1;
    for (; fromStart < from.length; ++fromStart) {
      if (from.charCodeAt(fromStart) !== 47 /*/*/)
        break;
    }
    var fromEnd = from.length;
    var fromLen = fromEnd - fromStart;

    // Trim any leading backslashes
    var toStart = 1;
    for (; toStart < to.length; ++toStart) {
      if (to.charCodeAt(toStart) !== 47 /*/*/)
        break;
    }
    var toEnd = to.length;
    var toLen = toEnd - toStart;

    // Compare paths to find the longest common path from root
    var length = fromLen < toLen ? fromLen : toLen;
    var lastCommonSep = -1;
    var i = 0;
    for (; i <= length; ++i) {
      if (i === length) {
        if (toLen > length) {
          if (to.charCodeAt(toStart + i) === 47 /*/*/) {
            // We get here if `from` is the exact base path for `to`.
            // For example: from='/foo/bar'; to='/foo/bar/baz'
            return to.slice(toStart + i + 1);
          } else if (i === 0) {
            // We get here if `from` is the root
            // For example: from='/'; to='/foo'
            return to.slice(toStart + i);
          }
        } else if (fromLen > length) {
          if (from.charCodeAt(fromStart + i) === 47 /*/*/) {
            // We get here if `to` is the exact base path for `from`.
            // For example: from='/foo/bar/baz'; to='/foo/bar'
            lastCommonSep = i;
          } else if (i === 0) {
            // We get here if `to` is the root.
            // For example: from='/foo'; to='/'
            lastCommonSep = 0;
          }
        }
        break;
      }
      var fromCode = from.charCodeAt(fromStart + i);
      var toCode = to.charCodeAt(toStart + i);
      if (fromCode !== toCode)
        break;
      else if (fromCode === 47 /*/*/)
        lastCommonSep = i;
    }

    var out = '';
    // Generate the relative path based on the path difference between `to`
    // and `from`
    for (i = fromStart + lastCommonSep + 1; i <= fromEnd; ++i) {
      if (i === fromEnd || from.charCodeAt(i) === 47 /*/*/) {
        if (out.length === 0)
          out += '..';
        else
          out += '/..';
      }
    }

    // Lastly, append the rest of the destination (`to`) path that comes after
    // the common path parts
    if (out.length > 0)
      return out + to.slice(toStart + lastCommonSep);
    else {
      toStart += lastCommonSep;
      if (to.charCodeAt(toStart) === 47 /*/*/)
        ++toStart;
      return to.slice(toStart);
    }
  },

  _makeLong: function _makeLong(path) {
    return path;
  },

  dirname: function dirname(path) {
    assertPath(path);
    if (path.length === 0) return '.';
    var code = path.charCodeAt(0);
    var hasRoot = code === 47 /*/*/;
    var end = -1;
    var matchedSlash = true;
    for (var i = path.length - 1; i >= 1; --i) {
      code = path.charCodeAt(i);
      if (code === 47 /*/*/) {
          if (!matchedSlash) {
            end = i;
            break;
          }
        } else {
        // We saw the first non-path separator
        matchedSlash = false;
      }
    }

    if (end === -1) return hasRoot ? '/' : '.';
    if (hasRoot && end === 1) return '//';
    return path.slice(0, end);
  },

  basename: function basename(path, ext) {
    if (ext !== undefined && typeof ext !== 'string') throw new TypeError('"ext" argument must be a string');
    assertPath(path);

    var start = 0;
    var end = -1;
    var matchedSlash = true;
    var i;

    if (ext !== undefined && ext.length > 0 && ext.length <= path.length) {
      if (ext.length === path.length && ext === path) return '';
      var extIdx = ext.length - 1;
      var firstNonSlashEnd = -1;
      for (i = path.length - 1; i >= 0; --i) {
        var code = path.charCodeAt(i);
        if (code === 47 /*/*/) {
            // If we reached a path separator that was not part of a set of path
            // separators at the end of the string, stop now
            if (!matchedSlash) {
              start = i + 1;
              break;
            }
          } else {
          if (firstNonSlashEnd === -1) {
            // We saw the first non-path separator, remember this index in case
            // we need it if the extension ends up not matching
            matchedSlash = false;
            firstNonSlashEnd = i + 1;
          }
          if (extIdx >= 0) {
            // Try to match the explicit extension
            if (code === ext.charCodeAt(extIdx)) {
              if (--extIdx === -1) {
                // We matched the extension, so mark this as the end of our path
                // component
                end = i;
              }
            } else {
              // Extension does not match, so our result is the entire path
              // component
              extIdx = -1;
              end = firstNonSlashEnd;
            }
          }
        }
      }

      if (start === end) end = firstNonSlashEnd;else if (end === -1) end = path.length;
      return path.slice(start, end);
    } else {
      for (i = path.length - 1; i >= 0; --i) {
        if (path.charCodeAt(i) === 47 /*/*/) {
            // If we reached a path separator that was not part of a set of path
            // separators at the end of the string, stop now
            if (!matchedSlash) {
              start = i + 1;
              break;
            }
          } else if (end === -1) {
          // We saw the first non-path separator, mark this as the end of our
          // path component
          matchedSlash = false;
          end = i + 1;
        }
      }

      if (end === -1) return '';
      return path.slice(start, end);
    }
  },

  extname: function extname(path) {
    assertPath(path);
    var startDot = -1;
    var startPart = 0;
    var end = -1;
    var matchedSlash = true;
    // Track the state of characters (if any) we see before our first dot and
    // after any path separator we find
    var preDotState = 0;
    for (var i = path.length - 1; i >= 0; --i) {
      var code = path.charCodeAt(i);
      if (code === 47 /*/*/) {
          // If we reached a path separator that was not part of a set of path
          // separators at the end of the string, stop now
          if (!matchedSlash) {
            startPart = i + 1;
            break;
          }
          continue;
        }
      if (end === -1) {
        // We saw the first non-path separator, mark this as the end of our
        // extension
        matchedSlash = false;
        end = i + 1;
      }
      if (code === 46 /*.*/) {
          // If this is our first dot, mark it as the start of our extension
          if (startDot === -1)
            startDot = i;
          else if (preDotState !== 1)
            preDotState = 1;
      } else if (startDot !== -1) {
        // We saw a non-dot and non-path separator before our dot, so we should
        // have a good chance at having a non-empty extension
        preDotState = -1;
      }
    }

    if (startDot === -1 || end === -1 ||
        // We saw a non-dot character immediately before the dot
        preDotState === 0 ||
        // The (right-most) trimmed path component is exactly '..'
        preDotState === 1 && startDot === end - 1 && startDot === startPart + 1) {
      return '';
    }
    return path.slice(startDot, end);
  },

  format: function format(pathObject) {
    if (pathObject === null || typeof pathObject !== 'object') {
      throw new TypeError('The "pathObject" argument must be of type Object. Received type ' + typeof pathObject);
    }
    return _format('/', pathObject);
  },

  parse: function parse(path) {
    assertPath(path);

    var ret = { root: '', dir: '', base: '', ext: '', name: '' };
    if (path.length === 0) return ret;
    var code = path.charCodeAt(0);
    var isAbsolute = code === 47 /*/*/;
    var start;
    if (isAbsolute) {
      ret.root = '/';
      start = 1;
    } else {
      start = 0;
    }
    var startDot = -1;
    var startPart = 0;
    var end = -1;
    var matchedSlash = true;
    var i = path.length - 1;

    // Track the state of characters (if any) we see before our first dot and
    // after any path separator we find
    var preDotState = 0;

    // Get non-dir info
    for (; i >= start; --i) {
      code = path.charCodeAt(i);
      if (code === 47 /*/*/) {
          // If we reached a path separator that was not part of a set of path
          // separators at the end of the string, stop now
          if (!matchedSlash) {
            startPart = i + 1;
            break;
          }
          continue;
        }
      if (end === -1) {
        // We saw the first non-path separator, mark this as the end of our
        // extension
        matchedSlash = false;
        end = i + 1;
      }
      if (code === 46 /*.*/) {
          // If this is our first dot, mark it as the start of our extension
          if (startDot === -1) startDot = i;else if (preDotState !== 1) preDotState = 1;
        } else if (startDot !== -1) {
        // We saw a non-dot and non-path separator before our dot, so we should
        // have a good chance at having a non-empty extension
        preDotState = -1;
      }
    }

    if (startDot === -1 || end === -1 ||
    // We saw a non-dot character immediately before the dot
    preDotState === 0 ||
    // The (right-most) trimmed path component is exactly '..'
    preDotState === 1 && startDot === end - 1 && startDot === startPart + 1) {
      if (end !== -1) {
        if (startPart === 0 && isAbsolute) ret.base = ret.name = path.slice(1, end);else ret.base = ret.name = path.slice(startPart, end);
      }
    } else {
      if (startPart === 0 && isAbsolute) {
        ret.name = path.slice(1, startDot);
        ret.base = path.slice(1, end);
      } else {
        ret.name = path.slice(startPart, startDot);
        ret.base = path.slice(startPart, end);
      }
      ret.ext = path.slice(startDot, end);
    }

    if (startPart > 0) ret.dir = path.slice(0, startPart - 1);else if (isAbsolute) ret.dir = '/';

    return ret;
  },

  sep: '/',
  delimiter: ':',
  win32: null,
  posix: null
};

posix.posix = posix;

module.exports = posix;

}).call(this)}).call(this,require('_process'))
},{"_process":3}],3:[function(require,module,exports){
// shim for using process in browser
var process = module.exports = {};

// cached from whatever global is present so that test runners that stub it
// don't break things.  But we need to wrap it in a try catch in case it is
// wrapped in strict mode code which doesn't define any globals.  It's inside a
// function because try/catches deoptimize in certain engines.

var cachedSetTimeout;
var cachedClearTimeout;

function defaultSetTimout() {
    throw new Error('setTimeout has not been defined');
}
function defaultClearTimeout () {
    throw new Error('clearTimeout has not been defined');
}
(function () {
    try {
        if (typeof setTimeout === 'function') {
            cachedSetTimeout = setTimeout;
        } else {
            cachedSetTimeout = defaultSetTimout;
        }
    } catch (e) {
        cachedSetTimeout = defaultSetTimout;
    }
    try {
        if (typeof clearTimeout === 'function') {
            cachedClearTimeout = clearTimeout;
        } else {
            cachedClearTimeout = defaultClearTimeout;
        }
    } catch (e) {
        cachedClearTimeout = defaultClearTimeout;
    }
} ())
function runTimeout(fun) {
    if (cachedSetTimeout === setTimeout) {
        //normal enviroments in sane situations
        return setTimeout(fun, 0);
    }
    // if setTimeout wasn't available but was latter defined
    if ((cachedSetTimeout === defaultSetTimout || !cachedSetTimeout) && setTimeout) {
        cachedSetTimeout = setTimeout;
        return setTimeout(fun, 0);
    }
    try {
        // when when somebody has screwed with setTimeout but no I.E. maddness
        return cachedSetTimeout(fun, 0);
    } catch(e){
        try {
            // When we are in I.E. but the script has been evaled so I.E. doesn't trust the global object when called normally
            return cachedSetTimeout.call(null, fun, 0);
        } catch(e){
            // same as above but when it's a version of I.E. that must have the global object for 'this', hopfully our context correct otherwise it will throw a global error
            return cachedSetTimeout.call(this, fun, 0);
        }
    }


}
function runClearTimeout(marker) {
    if (cachedClearTimeout === clearTimeout) {
        //normal enviroments in sane situations
        return clearTimeout(marker);
    }
    // if clearTimeout wasn't available but was latter defined
    if ((cachedClearTimeout === defaultClearTimeout || !cachedClearTimeout) && clearTimeout) {
        cachedClearTimeout = clearTimeout;
        return clearTimeout(marker);
    }
    try {
        // when when somebody has screwed with setTimeout but no I.E. maddness
        return cachedClearTimeout(marker);
    } catch (e){
        try {
            // When we are in I.E. but the script has been evaled so I.E. doesn't  trust the global object when called normally
            return cachedClearTimeout.call(null, marker);
        } catch (e){
            // same as above but when it's a version of I.E. that must have the global object for 'this', hopfully our context correct otherwise it will throw a global error.
            // Some versions of I.E. have different rules for clearTimeout vs setTimeout
            return cachedClearTimeout.call(this, marker);
        }
    }



}
var queue = [];
var draining = false;
var currentQueue;
var queueIndex = -1;

function cleanUpNextTick() {
    if (!draining || !currentQueue) {
        return;
    }
    draining = false;
    if (currentQueue.length) {
        queue = currentQueue.concat(queue);
    } else {
        queueIndex = -1;
    }
    if (queue.length) {
        drainQueue();
    }
}

function drainQueue() {
    if (draining) {
        return;
    }
    var timeout = runTimeout(cleanUpNextTick);
    draining = true;

    var len = queue.length;
    while(len) {
        currentQueue = queue;
        queue = [];
        while (++queueIndex < len) {
            if (currentQueue) {
                currentQueue[queueIndex].run();
            }
        }
        queueIndex = -1;
        len = queue.length;
    }
    currentQueue = null;
    draining = false;
    runClearTimeout(timeout);
}

process.nextTick = function (fun) {
    var args = new Array(arguments.length - 1);
    if (arguments.length > 1) {
        for (var i = 1; i < arguments.length; i++) {
            args[i - 1] = arguments[i];
        }
    }
    queue.push(new Item(fun, args));
    if (queue.length === 1 && !draining) {
        runTimeout(drainQueue);
    }
};

// v8 likes predictible objects
function Item(fun, array) {
    this.fun = fun;
    this.array = array;
}
Item.prototype.run = function () {
    this.fun.apply(null, this.array);
};
process.title = 'browser';
process.browser = true;
process.env = {};
process.argv = [];
process.version = ''; // empty string to avoid regexp issues
process.versions = {};

function noop() {}

process.on = noop;
process.addListener = noop;
process.once = noop;
process.off = noop;
process.removeListener = noop;
process.removeAllListeners = noop;
process.emit = noop;
process.prependListener = noop;
process.prependOnceListener = noop;

process.listeners = function (name) { return [] }

process.binding = function (name) {
    throw new Error('process.binding is not supported');
};

process.cwd = function () { return '/' };
process.chdir = function (dir) {
    throw new Error('process.chdir is not supported');
};
process.umask = function() { return 0; };

},{}],4:[function(require,module,exports){
var PMC = require( "pack-mc-2" )
var lua = require( "lua.js" )
// 对lua.js有微改动！
var mod = PMC.Addon.fromJSON( "lua-computer" )
mod.setNamespace( "mclua" )
mod.requireModule( "@minecraft/server-ui" )
mod.loadResources( "lua" )
mod.setEntryPack( "data/" )
mod.setEntry()
var ctx = mod.getAddonCtx()
var luactx = lua.newContext()
var block = ctx.Block( "Lua Computer", {
  texture: 3,
  destroy_time: 1, block_light_emission: 0.5
})
block.category = "items"
block.set( "loot", ctx.LootTable( block.getId()).toString() )
ctx.Recipe( block, {
  table: ["xxx", "x x", "xxx"], key: {x: "minecraft:iron_block"}
})
var i18n = ctx.plugins.i18n.new( "zh_CN" )
i18n.t( "tile." + block.object.subId() + ".name", "Lua电脑" )
ctx.onMinecraft((mc) => {
  luactx.loadStdLib()
  luactx._G.set( "mc", mc )
  luactx._G.set( "message", mc.print )
  // lua.js 多好的项目啊，可惜不更了似乎
  // 不过也好理解，纯js的lua解释器跟基于wasm的wasmoon什么的几乎没有优势
  var code = "message( \"Hello World\" )"
  mc.world.afterEvents.entityHitBlock.subscribe(({damagingEntity, hitBlock}) => {
    if( hitBlock.typeId == block.getId() && damagingEntity.typeId == "minecraft:player" ){
      var form = new mc.serverUi.ModalFormData()
      form.title( "Lua Computer" )
        .textField( "luaCode", code )
        // .submitButton( "Run it now！" ) 1.2.0不支持此方法
        .show(damagingEntity)
          .then(( fdata ) => {
            if( fdata.canceled ) return;
            try {
              code = fdata.formValues[0] || code
              luactx.loadString( code )()
            } catch( err ){
              mc.print( "[LuaError] " + err.toString() )
            }
          })
      .catch( console.error )
    }
  })
})
mod.generate()
},{"lua.js":6,"pack-mc-2":10}],5:[function(require,module,exports){
/**
 * Created by Yun on 2014/9/24.
 */

var PRETTY = true;

var gens = {};

var indent, pushIndent, popIndent;

if (PRETTY) {
    indent = "\n";

    pushIndent = function () {
        indent = indent + "    ";
    }
    popIndent= function (){
        indent = indent.substr(0, indent.length - 4);
    }
} else {
    indent = "";
    pushIndent = function (){}
    popIndent = function (){}
}

gens["function"] = function(ast){
    return "l._f(function(" + ast.args.join(',')+")" + codegen(ast.block)+")";
}

gens["jsfunction"] = function(ast){
    return "(function(" + ast.args.join(',')+")" + codegen(ast.block)+")";
}

gens["block"] = function(ast){
    var codes = [];
    pushIndent();
    for (var i = 0; i < ast.stats.length; i++){
        codes.push(codegen(ast.stats[i]));
    }
    popIndent();
    return indent + "{" +  codes.join("") +  indent + "}";
}

gens["stat.getvaargs"] = function(ast){
    return indent + "var __VA_ARG = Array.prototype.slice.call(arguments, " + ast.argCount +");";
}

gens["stat.expr"] = function(ast){
    return indent + codegen(ast.expr) + ";";
}

gens["stat.local"] = function(ast){
    if (!ast.right){
        return indent + "var " + ast.names.join(',') + ";"
    } else if (ast.names.length == 1){
        // a = exp
        return indent + "var " + ast.names[0] + " = " + codegenSimpleVar(ast.right[0]) + ";";
    } else {
        // var list = explist
        var names = [];
        for (var i = 0; i < ast.names.length; i++){
            names.push(ast.names[i] + " = t[" + i + "]");
        }
        //TODO: use a generated template varaiable name.
        return indent + "var t =" + codegenVarList(ast.right)+ "," +
            indent + names.join(",") + ";";
    }
}

gens["stat.if"] = function(ast){
    var base = indent + "if (" + codegenSimpleVar(ast.cond) + ")" + codegen(ast.tblock);

    if (ast.fblock && ast.fblock.stats.length > 0){
        if (ast.fblock.stats.length == 1 && ast.fblock.stats[0].type == "stat.if") {
            //try generate better code for elseif.
            return base + "else" + codegen(ast.fblock.stats[0]);
        } else {
            return base + "else" + codegen(ast.fblock);
        }
    }
    return base;
}

function codegenChecknumber(ast){
    if (ast.type == "const.number"){
        return codegen(ast);
    }
    return "l.__checknumber("+codegenSimpleVar(ast)+")";
}

gens["stat.fornum"] = function(ast){
    if (!ast.step){
        return indent + "for (var "+ast.varname+", " +
            ast.$var + " = " + codegenChecknumber(ast.from) + ", " +
            ast.$limit + " = " + codegenChecknumber(ast.to) + ";" +
            "("+ast.varname+"="+ast.$var+")<="+ast.$limit+";++" + ast.$var +")" +
            codegen(ast.block);
    } else {
        pushIndent();
        var block =
            indent + ast.varname + " = " + ast.$var + ";" +
            codegen(ast.block) +
            indent + ast.$var + " += " + ast.$step;
        popIndent();
        return indent + "var " +
            ast.$var + " = " + codegenChecknumber(ast.from) + ", " +
            ast.$limit + " = " + codegenChecknumber(ast.to) + ", " +
            ast.$step + " = " + codegenChecknumber(ast.step) + "," +
            ast.varname + ";" +
            indent + "while ((" + ast.$step + ">0 && " + ast.$var + "<=" + ast.$limit + ") || " +
            "(" + ast.$step + "<0 && " + ast.$var + ">=" + ast.$limit + ")){" +
            block +
            indent + "}";
    }
}

gens["stat.forlist"] = function(ast){
    pushIndent();
    var st = ast.$st;

    var ret = [];

    ret.push(indent + "var t = " + st+"[0]("+st+"[1],"+st+"[2]);");
    for (var i = 0; i < ast.varnames.length; ++i){
        ret.push(indent + "var " +ast.varnames[i] + " = t[" + i + "];");
    }
    ret.push(indent + "if ("+ ast.varnames[0]+" == null) break;");
    ret.push(indent + st+ "[2] = " + ast.varnames[0] + ";");
    ret.push(codegen(ast.block));
    popIndent();

    return indent + "var " + st + " = " + codegenVarList(ast.explist)+";" +
        indent + "for (;;)" +
        indent + "{" +
        ret.join("") +
        indent + "}"
}

gens["stat.while"] = function(ast){
    return indent + "while ("+ codegenSimpleVar(ast.cond)+")" + codegen(ast.block);
}

gens["stat.repeat"] = function(ast){
    return indent + "do " + codegen(ast.block) + "while (!(" + codegenSimpleVar(ast.until)+"));";
}

gens["stat.break"] = function(ast){
    return indent + "break;"
}

function isVarExpr(exp){
    if (exp.type == "vararg" || exp.type == "expr.call" || exp.type == "expr.callMethod") {
        return true;
    }
}

function isVarlist(explist){
    if (!explist.length){
        return false;
    }
    return isVarExpr(explist[explist.length - 1]);
}

function codegenSimpleVar(exp){
    if (isVarExpr(exp)) {
        return ('('+codegen(exp)+')' + "[0]");
    } else {
        return (codegen(exp));
    }
}

function codegenVarList(explist){
    if (isVarlist(explist)){
        if (explist.length == 1){
            return codegen(explist[0]);
        }
        var pres = [];
        for (var i = 0; i < explist.length-1; i++){
            pres.push(codegenSimpleVar(explist[i]));
        }
        return "[" + pres.join(',')+"].concat(" + codegen(explist[explist.length - 1]) + ")";
    } else {
        var pres = [];
        for (var i = 0; i < explist.length; i++){
            pres.push(codegenSimpleVar(explist[i]));
        }
        return "[" + pres.join(',')+"]";
    }
}

gens["vararg"] = function(ast){
    //TODO: throw a error when use __VA_ARG not in a va_arg function.
    return "__VA_ARG";
}

gens["stat.return"] = function(ast){
    if (isVarlist(ast.nret)){
        return indent + "return " + codegenVarList(ast.nret);
    } else {
        var nrets = [];
        for (var i = 0; i < ast.nret.length; i++){
            nrets.push(codegenSimpleVar(ast.nret[i]));
        }
        return indent + "return [" + nrets + "];";
    }
}

gens["stat.jsreturn"] = function(ast){
    return indent + "return " + codegenSimpleVar(ast.nret);
}

gens["stat.assignment"] = function(ast){
    if (ast.lefts.length == 1){
        //variable = explist
        var right = ast.right.length == 1 ? codegenSimpleVar(ast.right[0]) : (codegenVarList(ast.right) + "[0]");
        // single assignment
        if (ast.lefts[0].type == "expr.index") {
            //a[key] = value
            var tar = ast.lefts[0];
            return indent + "l.__set(" + codegenSimpleVar(tar.self)+", " +codegenSimpleVar(tar.key) + ", " + right + ");";
        }
        return indent + codegen(ast.lefts[0]) + " = " + right + ";";
    } else {
        // list = explist
        var ret = [];

        ret.push(indent + "var t = " + codegenVarList(ast.right) +";");
        for (var i = 0; i < ast.lefts.length; ++i){
            if (ast.lefts[i].type == "expr.index") {
                var tar = ast.lefts[i];
                ret.push(indent + "l.__set(" + codegenSimpleVar(tar.self) + "," + codegenSimpleVar(tar.key) + ",t[" +i+"]);");
            } else {
                ret.push(indent + codegen(ast.lefts[i]) + " = t[" + i + "];");
            }
        }
        return ret.join("");
    }
}

gens["expr.index"] = function(ast){
    return "l.__get(" + codegenSimpleVar(ast.self) + "," + codegenSimpleVar(ast.key)+")";
}

gens["expr.op"] = function(ast){
    var func;
    var op;
    switch(ast.op){
        case "op.add":
            func = "l.__add";
            break;
        case "op.minus":
            func = "l.__sub";
            break;
        case "op.mul":
            func = "l.__mul";
            break;
        case "op.div":
            func = "l.__div";
            break;
        case "op.mod":
            func = "l.__mod";
            break;
        case "op.pow":
            func = "l.__pow";
            break;
        case "op.concat":
            func = "l.__concat";
            break;
        case "op.equal":
            func = "l.__eq";
            break;
        case "op.less":
            func = "l.__lt";
            break;
        case "op.lessequal":
            func = "l.__le";
            break;
        case "op.notequal":
            func = "l.__neq";
            break;
        case "op.great":
            func = "l.__gt";
            break;
        case "op.greatequal":
            func = "l.__ge";
            break;
        case "op.and":
            op = "&&";
            break;
        case "op.or":
            op = "||";
            break;
        default:
            throw new Error(ast.op + " is not implemented yet.");
    }

    if (op){
        return codegenSimpleVar(ast.left) + op + codegenSimpleVar(ast.right);
    } else if (func){
        return func +"(" + codegenSimpleVar(ast.left) + "," + codegenSimpleVar(ast.right) + ")";
    }
}

gens["expr.uop"] = function(ast){
    switch (ast.op){
        case "uop.minus":
            return "l.__unm(" + codegenSimpleVar(ast.operand)+")";
        case "uop.not":
            return "!("+codegenSimpleVar(ast.operand)+")";
        case "uop.len":
            return "l.__len("+codegenSimpleVar(ast.operand) +")";
        default:
            throw new Error(ast.op + " is not implemented yet.");
    }
}

gens["expr.call"] = function(ast){
    var func = codegenSimpleVar(ast.func);
    return "l.__call("+func+","+ codegenVarList(ast.args) +")";
}

gens["expr.jscall"] = function(ast) {
    var func = codegenSimpleVar(ast.func);
    return func+".call(null, "+ codegenVarList(ast.args) +")";
}

gens["expr.callMethod"] = function(ast){
    return "l.__callMethod(" + codegenSimpleVar(ast.self) + "," + codegenSimpleVar(ast.key) + "," + codegenVarList(ast.args) +")";
}

gens["expr.brackets"] = function(ast){
    if (isVarExpr(ast.expr)) {
        return codegenSimpleVar(ast.expr);
    } else {
        return '(' + codegen(ast.expr)+ ")";
    }
}

gens["expr.constructor"] = function(ast){
    if (!ast.fields.length){
        return "l.__newTable()";
    }
    var fields = [];
    for (var i = 0; i < ast.fields.length; i++){
        var f = ast.fields[i];
        if (f.type == "field.list"){
            if (isVarExpr(f.val) && i == ast.fields.length - 1){
                fields.push("[2, " + codegen(f.val) + "]");
            } else {
                fields.push("[0, " + codegenSimpleVar(f.val) + "]");
            }
        } else if (f.type == "field.rec"){
            fields.push("[1, " + codegen(f.key) + "," + codegenSimpleVar(f.val) + "]");
        } else {
            throw new Error("Invalid field type "+ f.type);
        }
    }
    return "l.__newTable([" + fields.join(",")+ "])";
}

gens["variable"] = function(ast){
    return ast.val;
}

gens["const.string"] = function(ast){
    return ast.val ? JSON.stringify(ast.val) : "l.ds";
}
gens["const.number"] = function(ast){
    return ast.val ? JSON.stringify(ast.val) : "l.d0";
}
gens["const.boolean"] = function(ast){
    return JSON.stringify(ast.val);
}

gens["const.nil"] = function(ast){
    return "null";
}

gens["expr.javascript"] = function(ast){
    if (ast.args.length != 1){
        throw new Error("__javascript should have exactly one arguments.");
    }
    if (ast.args[0].type == "const.string") {
        return '(' + ast.args[0].val + ")";
    } else {
        return 'eval(' + codegenSimpleVar(ast.args[0]) +")";
    }
}

function codegen(ast){
    if (gens[ast.type]){
        return gens[ast.type](ast);
    }
    throw new Error("Unsupported ast type " + ast.type);
}

var childfields = {
    "expr.uop": ["operand"],
    "expr.op": ["left", "right"],
    "stat.assignment":["lefts", "right"],
    "stat.expr": ["expr"],
    "field.list": ["val"],
    "field.rec": ["key", "val"],
    "expr.constructor": ["fields", "recs", "list"],
    "stat.if": ["cond", "tblock", "fblock"],
    "stat.fornum": ["from", "to", "step", "block"],
    "stat.forlist": ["explist", "block"],
    "stat.while": ["cond", "block"],
    "stat.repeat": ["until", "block"],
    "expr.index": ["self", "key"],
    "expr.callMethod": ["self", "key", "args"],
    "expr.call": ["func", "args"],
    "expr.brackets": ["expr"],
    "stat.method": ["self", "key", "func"],
    "stat.function": ["left", "func"],
    "stat.localfunction": ["func"],
    "stat.local": ["right"],
    "stat.return": ["nret"],
    "function": ["block"],
    "block": ["stats"]
}

function traverse(func, out){
    return function (ast) {
        function work(curr, parent) {
            if (curr && curr.constructor == Array) {
                for (var i = 0; i < curr.length; i++) {
                    curr[i] = work(curr[i], parent);
                }
                return curr;
            } else if (curr && curr.type) {
                var ret = func(curr, parent) || curr;
                var fields = childfields[ret.type];
                if (fields) {
                    for (var i = 0; i < fields.length; i++) {
                        ret[fields[i]] = work(ret[fields[i]], ret);
                    }
                }

                if (out){
                    ret = out(ret, parent) || ret;
                }

                return ret;
            }
        }
        return work(ast);
    }
}
exports.traverse = traverse;

exports.phases = [];

exports.postphases = [];

exports.run = function(ast){
//    console.log("\n");
    for (var i= 0; i < exports.phases.length; i++){
//        console.log(require("jsonf")(JSON.stringify(ast)));
        ast = exports.phases[i](ast);
//        console.log("\n");
    }
    //console.log(require("jsonf")(JSON.stringify(ast)));
    var ret =  codegen(ast);
//    var ret = "";
    for (var i= 0; i < exports.postphases.length; i++){
//        console.log(ret);
        ret = exports.postphases[i](ret);
    }
//    console.log(ret);
    return ret;
};

// process stat.localfunc & stat.local
(function(){
    exports.phases.push(traverse(function(ast){
        switch (ast.type ) {
            case 'function':{
                if (ast.varargs){
                    ast.block.stats.unshift({
                        type: "stat.getvaargs",
                        argCount: ast.args.length
                    });
                }

                // add return for function that does not return a value.
                var stats = ast.block.stats;
                if (stats.length == 0 || stats[stats.length-1].type != "stat.return"){
                    stats.push({
                        type: 'stat.return',
                        nret: []
                    });
                }
                break;
            }
            case "block":{
                var out = [];
                for (var i= 0; i < ast.stats.length; i++){
                    var curr = ast.stats[i];
                    switch (curr.type){
                        case 'stat.localfunction':{
                            // local function a  -> local a = function()
                            out.push({
                                type: 'stat.local',
                                names: [curr.name]
                            });
                            out.push({
                                type: 'stat.assignment',
                                lefts: [{
                                    type: "variable",
                                    val: curr.name
                                }],
                                right: [curr.func]
                            })
                            break;
                        }

                        case 'stat.function':{
                            out.push({
                                type: 'stat.assignment',
                                lefts: [curr.left],
                                right: [curr.func]
                            });
                            break;
                        }

                        case 'stat.method':{
                            curr.func.args.unshift("self");
                            out.push({
                                type: 'stat.assignment',
                                lefts: [{
                                    type: "expr.index",
                                    self: curr.self,
                                    key: curr.key
                                }],
                                right: [curr.func]
                            });
                            break;
                        }

                        default:
                            out.push(ast.stats[i]);
                    }
                }
                ast.stats = out;
            }
        }
    }));
})();

//phase: check global variable;
(function(){
    exports.phases.push(function(ast){
        var blocklevel = [];
        var top;
        var varNames = {};
        var varId = 0;
        ast = traverse(function(curr){
            var names;
            switch(curr.type){
                case 'block':{
                    names = [];
                    break;
                }
                case 'function':{
                    names = curr.args;
                    break;
                }
                case 'stat.fornum':{
                    names = [curr.varname, "$var", "$limit", "$step"];
                    break;
                }
                case 'stat.forlist':{
                    names = curr.varnames;
                    names.push("$st");
                    break;
                }
                case 'variable':{
                    if (varNames[curr.val]) {
                        var ref;
                        var stack = varNames[curr.val];
                        if (top.curr.type == "fornum" || top.curr.type == "forlist"){
                            // defining for head.
                            // body will in another block;

                            //check whether there's another define.
                            if (stack[stack.length-1] != top.curr){
                                ref = stack[stack.length - 1];
                            } else if (stack.length > 1){
                                ref = stack[stack.length - 2];
                            }
                        } else {
                            ref = stack[stack.length - 1];
                        }
                        if (ref){
                            curr.val = curr.val + "$" + ref.id;
                            return ;
                        }
                    }
                    if (curr.val == '_ENV'){
                        return ;
                    }
                    // global variable. use _ENV[name]
                    return {
                        "type": "expr.index",
                        "self": {
                            "type": "variable",
                            "val": "_ENV"
                        },
                        "key": {
                            "type": "const.string",
                            "val": curr.val
                        }
                    }
                }
            }
            if (names){
                if (top) {
                    blocklevel.push(top);
                }
                top = {
                    curr: curr,
                    names: names.slice(0)
                };
                for (var i= 0; i < names.length; i++){
                    var name = names[i];
                    varNames[name] = varNames[name] || [];
                    var id = ++varId;
                    names[i] = name + "$" + id;
                    varNames[name].push({
                        id: id,
                        curr: curr
                    });
                }

                if (curr.type == 'stat.fornum'){
                    curr.varname = names[0];
                    curr.$var = names[1];
                    curr.$limit = names[2];
                    curr.$step = names[3];
                } else if (curr.type == "stat.forlist") {
                    curr.$st = names.pop();
                }
            }
        }, function(curr){
            if (top && top.curr == curr) {
                for (var i = 0; i < top.names.length; i++){
                    var name = top.names[i];
                    varNames[name].pop();//assert == blocklevel
                    if (varNames[name].length == 0){
                        delete varNames[name];
                    }
                }
                top = blocklevel.pop();
            } else if (curr.type == 'stat.local') {
                //Define local variables in current block.
                // define when out of this statement to avoid effecting initialize list.
                //add to current block;
                for (var i= 0; i < curr.names.length; i++){
                    var name = curr.names[i];
                    varNames[name] = varNames[name] || [];
                    var stack = varNames[name];
                    if (stack.length > 0 && stack[stack.length-1] === top){
                        // variable redefined.
                        var id = stack[stack.length - 1].id = ++varId;
                        curr.names[i] = name + "$" + id;
                        continue;
                    }
                    var id = ++varId;
                    curr.names[i] = name + "$" + id;
                    stack.push({
                        id: id,
                        curr: top.curr
                    });
                    top.names.push(name);
                }
            }
        })(ast);
        return ast;
    });
})();

function transformBreak(block) {
    function work(curr, parent) {
        if (curr && curr.constructor == Array) {
            for (var i = 0; i < curr.length; i++) {
                curr[i] = work(curr[i], parent);
            }
            return curr;
        } else if (curr && curr.type) {
            if (curr.type === 'function' ||
                curr.type === 'stat.fornum' ||
                curr.type === 'stat.forlist' ||
                curr.type === 'stat.while' ||
                curr.type === 'stat.repeat') {
                return curr;
            }
            var ret = curr;
            if (curr.type === 'stat.break') {
                return  {
                    "type": "stat.jsreturn",
                    "nret": {
                        type: "const.boolean",
                        val: true
                    }
                };
            }
            var fields = childfields[ret.type];
            if (fields) {
                for (var i = 0; i < fields.length; i++) {
                    ret[fields[i]] = work(ret[fields[i]], ret);
                }
            }

            return ret;
        }
    }
    return work(block);
}

// Fix issue #2
(function(){
    exports.phases.push(function(ast) {
        var stack = [];
        ast = traverse(function(curr){
            switch(curr.type){
                case 'function':
                {
                    if (stack.length > 0){
                        var top = stack[stack.length-1];
                        for (var i= 0; i < top.length; i++){
                            top[i].has_closure = true;
                        }
                    }
                    stack.push([]);
                    break;
                }
                case 'stat.fornum':
                case 'stat.forlist':
                case 'stat.repeat':
                case 'stat.while':
                {
                    stack[stack.length-1].push(curr);
                }
                break;
            }
        }, function(curr){
            switch(curr.type){
                case 'function':
                {
                    stack.pop();
                    break;
                }
                case 'stat.fornum':
                case 'stat.forlist':
                {
                    if (curr.has_closure){
                        var block = curr.block;

                        /*
                            for (var i= 0; i < 100; i++){
                                if (function(i){
                                }(i)) break;
                            }
                        */

                        var newBlock = {
                            "type": "block",
                            "stats": [
                                {
                                    "type": "stat.if",
                                    "cond": {
                                        "type": "expr.jscall",
                                        "func": {
                                            "type": "jsfunction",
                                            "args": [
                                                curr.varname
                                            ],
                                            "varargs": false,
                                            block: transformBreak(block),
                                        },
                                        "args": [
                                            {
                                                "type" : "variable",
                                                "val": curr.varname
                                            }
                                        ]
                                    },
                                    "tblock" : [
                                        {
                                            "type": "stat.break"
                                        }
                                    ]
                                }
                            ]
                        }
                        curr.block = newBlock;
                    }
                    break;
                }
                case 'stat.repeat':
                case 'stat.while':
                {
                    var block = curr.block;

                    /*
                     for (var i= 0; i < 100; i++){
                     function(i){
                     }(i)
                     }
                     */

                    var newBlock = {
                        "type": "block",
                        "stats": [
                            {
                                "type": "stat.if",
                                "cond": {
                                    "type": "expr.jscall",
                                    "func": {
                                        "type": "jsfunction",
                                        "args": [
                                        ],
                                        "varargs": false,
                                        block: transformBreak(block),
                                    },
                                    "args": [
                                    ]
                                },
                                "tblock" : {
                                    "type": "block",
                                    "stats": [
                                        {
                                            "type": "stat.break"
                                        }
                                    ]
                                }
                            }
                        ]
                    }
                    curr.block = newBlock;
                    break;
                }
            }
        })(ast);
        return ast;
    });
})();

var sign = "/*lua.js generated code*/";
exports.sign = sign;
//Post-Phase: add _ENV upvalue for whole scope.
(function() {
    exports.postphases.push(function(code){
        code = sign + 'return '+code+';';
        return code;
    });
})();

},{}],6:[function(require,module,exports){
/**
 * Created by Yun on 2014/9/23.
 */

// Compile
var parser = require("./parser.js");
exports.parser = parser;
var codegen = require("./codegen.js");
exports.codegen = codegen;
var sign = codegen.sign;

function compile(s){
    if (s.substr(0, sign.length) != sign) {
        return codegen.run(parser.parse(s));
    } else {
        return s;
    }
}
exports.compile = compile;

var types = require("./types.js");
exports.types = types;

var dummy0 = types.dummy0;
var dummyStr = types.dummyStr;

function LuaContext(){
    if (!(this instanceof  LuaContext)){
        return new LuaContext();
    }
    // Globals for lua usage.
    var _G = new types.LuaTable();
    this._G = _G;
    _G.set("_G", _G);
    _G.set("_VERSION", "Lua 5.2");
    _G.set("_LUAJS", "Lua.js 0.1");

    var helpers = {};

    helpers.d0 = dummy0;
    helpers.ds = dummyStr;
    helpers.LuaTable = types.LuaTable;

    helpers.__getmetatable = function(t){
        if (!t){
            return null;
        }
        switch(typeof(t)){
            case 'object':
                return t.metatable || ((t instanceof types.LuaTable) ? null : helpers.jsObjMT);
            case 'string':
                return helpers.stringMT;
            case 'function':
                if (!f.__lua_function){
                    return helpers.jsFuncMT;
                }
            default:
                return null;
        }
    }

    helpers._f = function(f){
        f.__lua_function = true;
        return f;
    }

    function getMTMethod(t, e){
        var mt = helpers.__getmetatable(t);
        return mt && mt.stringMap && mt.stringMap[e] && mt.stringMap[e][1];
    }

    //getter & setter
    helpers.__get = function(s, k){
        var h;
        if (s instanceof types.LuaTable){
            var v = s.get(k);
            if (v !== null && v!==undefined){
                return v;
            }
            h = getMTMethod(s, "__index");
            if (!h){
                return null;
            }
        } else if (typeof(s) == 'object' || (typeof(s) == 'function' && !s.__lua_function)) {
            if (typeof(s) == 'function' && s.__beforeBind){
                s = s.__beforeBind;
            }
            var ret = typeof(k)=='number'?s[k-1]:s[k];
            if (typeof(ret) == 'function'){
                var ret1 = ret.bind(s);
                ret1.__beforeBind = ret;
                return ret1;
            } else if (!ret && k == "new") {
                var dummy = function(){};
                dummy.prototype = s.prototype;
                return function(){
                    var ret = new dummy();
                    t.apply(ret, arguments);
                    return ret;
                }
            }
            return ret;
        } else {
            h = getMTMethod(s, "__index");
            if (!h){
                throw new Error("attempt to index a "+helpers.__type(s)+" value.");
            }
        }
        if (typeof(h) == "function"){
            return helpers.__call(h, [s, k])[0];
        }
        return helpers.__get(h, k);
    }
    helpers.__set = function(s, k, v){
        var h;
        if (s instanceof types.LuaTable){
            var oldv = s.get(k);
            if (oldv){
                s.set(k, v);
                return;
            }
            h = getMTMethod(s, "__newindex");
            if (!h){
                s.set(k, v);
                return
            }
        } else if (typeof(s) == 'object' || (typeof(s) == 'function' && !s.__lua_function)) {
            s[k] = v;
            return;
        } else {
            h = getMTMethod(s, "__newindex")
            if (!h){
                throw new Error("attempt to index a "+helpers.__type(s)+" value.");
            }
        }
        if (typeof(h) == "function"){
            helpers.__call(h, [s,k,v]);
        } else {
            helpers.__set(h, k, v);
        }
    };

    // operators:
//    function defineNumberOper(name, opf){
//        helpers[name] = function(a, b){
//            if (typeof(a) == 'number' && typeof(b) == 'number'){
//                return opf(a, b)||dummy0;
//            }
//            var o1 = helpers.__tonumber(a), o2 = helpers.__tonumber(b);
//            if (o1 && o2) {
//                return opf(o1, o2)||dummy0;
//            }
//            var h = getMTMethod(a, name) || getMTMethod(b, name)
//            if (h){
//                return helpers.__call(h, [a, b])[0];
//            }
//            throw new Error("attempt to perform arithmetic on a " + helpers.__type(a)+" value");
//        }
//    }
    helpers.__add = function(a, b){
        if (typeof(a) == 'number' && typeof(b) == 'number'){
            return (a+b)||dummy0;
        }
        var o1 = helpers.__tonumber(a), o2 = helpers.__tonumber(b);
        if (o1 && o2) {
            return (o1+o2)||dummy0;
        }
        var h = getMTMethod(a, "__add") || getMTMethod(b, "__add")
        if (h){
            return helpers.__call(h, [a, b])[0];
        }
        throw new Error("attempt to perform arithmetic on a " + helpers.__type(a)+" value");
    }
    helpers.__sub = function(a, b){
        if (typeof(a) == 'number' && typeof(b) == 'number'){
            return (a-b)||dummy0;
        }
        var o1 = helpers.__tonumber(a), o2 = helpers.__tonumber(b);
        if (o1 && o2) {
            return (a-b)||dummy0;
        }
        var h = getMTMethod(a, "__sub") || getMTMethod(b, "__sub")
        if (h){
            return helpers.__call(h, [a, b])[0];
        }
        throw new Error("attempt to perform arithmetic on a " + helpers.__type(a)+" value");
    }
    helpers.__mul = function(a, b){
        if (typeof(a) == 'number' && typeof(b) == 'number'){
            return (a*b)||dummy0;
        }
        var o1 = helpers.__tonumber(a), o2 = helpers.__tonumber(b);
        if (o1 && o2) {
            return (a*b)||dummy0;
        }
        var h = getMTMethod(a, "__mul") || getMTMethod(b, "__mul")
        if (h){
            return helpers.__call(h, [a, b])[0];
        }
        throw new Error("attempt to perform arithmetic on a " + helpers.__type(a)+" value");
    }
    helpers.__div = function(a, b){
        if (typeof(a) == 'number' && typeof(b) == 'number'){
            return (a/b)||dummy0;
        }
        var o1 = helpers.__tonumber(a), o2 = helpers.__tonumber(b);
        if (o1 && o2) {
            return (a/b)||dummy0;
        }
        var h = getMTMethod(a, "__div") || getMTMethod(b, "__div")
        if (h){
            return helpers.__call(h, [a, b])[0];
        }
        throw new Error("attempt to perform arithmetic on a " + helpers.__type(a)+" value");
    }
    helpers.__mod = function(a, b){
        if (typeof(a) == 'number' && typeof(b) == 'number'){
            return (a%b)||dummy0;
        }
        var o1 = helpers.__tonumber(a), o2 = helpers.__tonumber(b);
        if (o1 && o2) {
            return (a%b)||dummy0;
        }
        var h = getMTMethod(a, "__mod") || getMTMethod(b, "__mod")
        if (h){
            return helpers.__call(h, [a, b])[0];
        }
        throw new Error("attempt to perform arithmetic on a " + helpers.__type(a)+" value");
    }
    helpers.__pow = function(a, b){
        if (typeof(a) == 'number' && typeof(b) == 'number'){
            return (Math.pow(a,b))||dummy0;
        }
        var o1 = helpers.__tonumber(a), o2 = helpers.__tonumber(b);
        if (o1 && o2) {
            return (Math.pow(a,b))||dummy0;
        }
        var h = getMTMethod(a, "__pow") || getMTMethod(b, "__pow")
        if (h){
            return helpers.__call(h, [a, b])[0];
        }
        throw new Error("attempt to perform arithmetic on a " + helpers.__type(a)+" value");
    }


//
//    defineNumberOper("__add", function(a,b){return a+b;});
//    defineNumberOper("__mul", function(a,b){return a*b;});
//    defineNumberOper("__sub", function(a,b){return a-b;});
//    defineNumberOper("__div", function(a,b){return a/b;});
//    defineNumberOper("__mod", function(a,b){return a%b;});
//    defineNumberOper("__pow", function(a,b){return Math.pow(a,b);});

    helpers.__unm = function(a){
        var o = helpers.__tonumber(a);
        if (o) {
            return -o;
        }
        var h = getMTMethod(a).__unm
        if (h) {
            return helpers.__call(h, [a])[0];
        }
        throw new Error("attempt to perform arithmetic on a " + helpers.__type(a)+" value");
    }

    helpers.__eq = function(a, b){
        return !helpers.__neq(a, b);
    }

    helpers.__neq = function(a,b){
        if (a===b){
            return false
        }
        var ta = helpers.__type(a);
        var tb = helpers.__type(b);
        if (ta === 'nil' && tb === 'nil') {
            return false;
        }
        if (ta !== tb || (ta != 'table' && ta !="userdata")){
            return true;
        }
        var h1 = getMTMethod(a, "__eq");
        var h2 = getMTMethod(b, "__eq");
        if (!h1 || h1 != h2){
            return true;
        }
        return !(helpers.__call(h1, [a, b])[0]);
    }

    helpers.__gt = function(a, b){
        return helpers.__lt(b, a);
    }

    helpers.__ge = function(a, b){
        return helpers.__le(b, a);
    }

    helpers.__lt = function(a, b){
        var ta = helpers.__type(a);
        var tb = helpers.__type(b);
        if ((ta=="number" && tb == "number") ||
            (ta == "string" && tb == "string"))  {
            return a < b;
        } else {
            var h = getMTMethod(a, "__lt") || getMTMethod(a, "__lt");
            if (h){
                return !!(helpers.__call(h1, [a, b])[0]);
            }
            throw new Error("attempt to compare " + helpers.__type(a)+" with " + helpers.__type(b));
        }
    }

    helpers.__le = function(a, b){
        var ta = helpers.__type(a);
        var tb = helpers.__type(b);
        if ((ta=="number" && tb == "number") ||
            (ta == "string" && tb == "string"))  {
            return a <= b;
        } else {
            var h = getMTMethod(a, "__le") || getMTMethod(a, "__le");
            if (h){
                return !!(helpers.__call(h1, [a, b])[0]);
            }
            h = getMTMethod(a, "__lt") || getMTMethod(a, "__lt");
            if (h){
                return !(helpers.__call(h1, [a, b])[0]);
            }
            throw new Error("attempt to compare " + helpers.__type(a)+" with " + helpers.__type(b));
        }
    }

    helpers.__concat = function(a, b){
        var ta = helpers.__type(a);
        var tb = helpers.__type(b);
        if ((ta == 'number' || ta == 'string') &&
            (tb == 'number' || tb == 'string')){
            return (""+a.toString()+b.toString()) || dummyStr;
        }
        var h = getMTMethod(a, "__concat") || getMTMethod(b, "__concat")
        if (h){
            return helpers.__call(h1, [a, b])[0];
        }
        throw new Error("attempt to concatenate a " + helpers.__type(a)+" value");
    }

    // other functions
    helpers.__newTable = function(fields){
        var ret = new types.LuaTable(fields);
        return ret;
    }

    helpers.__len = function(c){
        switch(typeof(c)){
            case 'string':
                return c.length;
        }
        var h = getMTMethod(c, "__len");
        if (h){
            return helpers.__call(h, [a])[0];
        }
        if (c instanceof types.LuaTable) {
            return c.length();
        }
        if (typeof(c) ==  'object' && c.length){
            return c.length;
        }
        throw new Error("attempt to get length of a " + helpers.__type(c)+" value");
    }

    helpers.__tonumber = function(c){
        switch(typeof(c)){
            case 'number':
              if (!c){return dummy0}
                return c;
            case 'string':
            {
                var n = parseInt(c);
                if (isNaN(n)) {
                    return null;
                }
                return n || dummy0;
            }
            default:
                if (c == dummy0){
                    return c;
                }
        }

        return null;
    }

    helpers.__checknumber = function(c){
        switch(typeof(c)){
            case 'number':
                return c;
            case 'string':
            {
                var n = parseInt(c);
                if (isNaN(n)) {
                    throw new Error("Not a number.");
                }
                return n || dummy0;
            }
        }
        if (c == dummy0){
            return c;
        }
        throw new Error("Not a number.");
    }

    helpers.__tostring = function(c){
        if (c === null || c === undefined){
            return "nil";
        }
        switch(typeof(c)){
            case 'number':case 'boolean':
                return c.toString();
            case 'string':
                return c;
            case 'function':
                c._hashKey = c._hashKey || types.newHashKey();
                return 'function('+ c._hashKey+")";
            case 'object':
                if (c == dummy0){
                    return "0";
                }
                if (c == dummyStr){
                    return dummyStr;
                }
                var h = getMTMethod(c, "__tostring");
                if (h){
                    return helpers.__call(h, [c])[0];
                }

                if (c.toString) {
                    return c.toString();
                }
            default:
                return "userdata("+ c + ")";
        }
    }

    helpers.__type = function(c){
        if (c == null){
            return "nil";
        }
        var t = typeof(c);
        switch(t){
            case 'number':case 'boolean':case 'string':case 'function':
                return t;
            case 'object':
                if (c == dummy0){
                    return "number";
                }
                if (c == dummyStr){
                    return "string";
                }
                if (c instanceof types.LuaTable) {
                    return "table";
                }
            default:
                return "userdata";
        }
    }

    helpers.__call = function(f, args){
        if (typeof(f) == 'function'){
            if (f.__lua_function) {
                return f.apply(null, args);
            } else {
                return [f.apply(null, args)];
            }
        }
        var h = getMTMethod(f, "__call");
        if (h){
            args.unshift(h);
            return helpers.__call(h, args);
        }
        throw new Error("attempt to call a " + helpers.__type(f)+" value");
    }

    helpers.__callMethod = function(s, k, args){
        args.unshift(s);
        //helpers.__get(s, k).apply(null, args);
        return helpers.__call(helpers.__get(s, k), args);
    }

    helpers.__dump = function(f){
        if (typeof(f) != "function"){
            throw new Error("bad argument #1 to `dump` (function expected, got " + helpers.__type(f) + ")");
        }
        return codegen.sign + "return "+ f.toString()+";"
    }

    this.loadString = helpers.__loadString = function(s, env){
        s = compile(s);
        //TODO; add extra info for s
        return new Function('_ENV', 'l', s)(env || _G, helpers);
    }

    this.loadStdLib = function(){
        if (!exports.stdlib){
            var fs = require("pack-mc-2/src/ActiveCore/VirtualFileSystem");
            var path = require("path");
            // 微改动
            var code = fs.readFileSync("stdlib.lua", {encoding:'utf-8'});
            exports.stdlib = new Function('_ENV', 'l', exports.compile(code));
        }
        exports.stdlib(_G, helpers)();
    }

    this.__helpers = helpers;
}

LuaContext.prototype = {}

exports.LuaContext = exports.newContext = LuaContext;

},{"./codegen.js":5,"./parser.js":8,"./types.js":9,"pack-mc-2/src/ActiveCore/VirtualFileSystem":12,"path":2}],7:[function(require,module,exports){
/**
 * Created by Yun on 2014/9/23.
 */

var tokens = [
    "<eof>",
    "and", "break", "do", "else", "elseif",
    "end", "false", "for", "function", "goto", "if",
    "in", "local", "nil", "not", "or", "repeat",
    "return", "then", "true", "until", "while",
    "..", "...", "==", ">=", "<=", "~=", "::", "<--orgion-eof>",
    "<number>", "<name>", "<string>",
    "__javascript", "__jsreturn"
];
exports.tokens = tokens;

var reserved = {
    "and":1,
    "break":2, "do":3, "else":4, "elseif":5,
    "end":6, "false":7, "for":8, "function":9, "goto":10, "if":11,
    "in":12, "local":13, "nil":14, "not":15, "or":16, "repeat":17,
    "return":18, "then":19, "true":20, "until":21, "while":22,

    "__javascript":34,
    "__js": 34,
    "__jsreturn": 35
}

var TK = {
    TK_EOS: 0,

    /* terminal symbols denoted by reserved words */
    TK_AND : 1,
    TK_BREAK : 2,
    TK_DO : 3,
    TK_ELSE : 4,
    TK_ELSEIF : 5,
    TK_END : 6,
    TK_FALSE : 7,
    TK_FOR : 8,
    TK_FUNCTION : 9,
    TK_GOTO : 10,
    TK_IF : 11,
    TK_IN : 12,
    TK_LOCAL : 13,
    TK_NIL : 14,
    TK_NOT : 15,
    TK_OR : 16,
    TK_REPEAT : 17,
    TK_RETURN : 18,
    TK_THEN : 19,
    TK_TRUE : 20,
    TK_UNTIL : 21,
    TK_WHILE : 22,
    /* other terminal symbols */
    TK_CONCAT : 23,
    TK_DOTS: 24,
    TK_EQ: 25,
    TK_GE: 26,
    TK_LE: 27,
    TK_NE: 28,
    TK_DBCOLON:29,

    TK_NUMBER:31,
    TK_NAME: 32,
    TK_STRING: 33,

    TK_JAVASCRIPT: 34,
    TK_JSRETURN: 35
};

exports.TK = TK;

var lalphaExp = /^[A-Za-z\_]$/;
function lislalpha(ch){
    return lalphaExp.test(ch);
}

var digitExp = /^[0-9]$/;
function lisdigit(ch){
    return digitExp.test(ch);
}

var hexdigitExp = /^[0-9a-fA-F]$/
function lishexdigit(ch){
    return hexdigitExp.test(ch);
}

var lalnumExp = /^[0-9A-Za-z\_]$/;
function lislalnum(ch){
    return lalnumExp.test(ch);
}

function isNewLine(ch){
    return ch=='\n' || ch == '\r';
}

/*
 ** skip a sequence '[=*[' or ']=*]' and return its number of '='s or
 ** -1 if sequence is malformed
 */
function skip_sep(curr, next, save){
    var count = 0;
    var ch = curr();
    if (ch != '[' && ch != ']'){
        throw "Lexical internal error!";
    }
    if (save){
        save(ch);
    }
    next()
    while (curr() == '='){
        next();
        if (save){
            save(curr());
        }
        ++count;
    }
    return curr() == ch ? count : (-count - 1);
}

function inclinenumber(curr, next){
    var old = curr();
    next();
    if (isNewLine(curr()) && curr() != old){
        next();
    }
}

//TODO: avoid wasting space when read comments.
function read_long_string(curr, next, sep){
    var buff = [];
    function save(ch){
        buff.push(ch);
    }
    next();/* skip 2nd `[' */
    /* string starts with a newline? */
    if (isNewLine(curr())){
        inclinenumber(curr, next);
    }
    for (;;){
        var ch = curr();
        switch(ch){
            case null:
                throw "unfinished long string/comment";
            case ']':{
                if (skip_sep(curr, next, save) == sep){
                    /* skip 2nd `]' */
                    next();
                    buff.splice(-sep-1, sep+1);
                    return buff.join("");
                }
                break;
            }
            case '\n':case '\r':{
                inclinenumber(curr, next);
                save('\n');     /* avoid wasting space */
                break;
            }
            default:{
                save(ch);
                next();
            }
        }
    }
}

//TODO: support utf8 `\` escape.
function read_string(curr, next){
    var buff = [];
    var beginCh = curr();
    next();
    var currCh;
    while ((currCh = curr()) != beginCh){
        switch (currCh){
            case null:
                throw "unfinished string";
            case '\n':
            case '\r':
                throw "unfinished string";
            case '\\':{
                next();
                currCh = curr();
                switch (currCh){
//                    case 'a': buff.push('\a'); next(); break;
                    case 'b': buff.push('\b'); next(); break;
                    case 'f': buff.push('\f'); next(); break;
                    case 'n': buff.push('\n'); next(); break;
                    case 'r': buff.push('\r'); next(); break;
                    case 't': buff.push('\t'); next(); break;
                    case 'v': buff.push('\t'); next(); break;
                    case '\n': case '\r': {
                        buff.push('\n');
                        inclinenumber();
                        break;
                    }
                    case '\\': case '\"': case '\'':{
                        buff.push(currCh);
                        next();
                        break;
                    }
                    case null:
                        throw "unfinished string";

                    case 'z':{
                        next();
                        while (lisspace(curr())){
                            next();
                        }
                        break;
                    }

                    case 'x': throw "esacpe for char code not supported in lua.js yet.";
                    default:{
                        if (!lisdigit(currCh)){
                            throw "invalid escape sequence" + currCh;
                        }
                        throw "esacpe for char code not supported in lua.js yet.";
                    }
                }
                break;
            }
            default: {
                buff.push(currCh);
                next();
            }
        }
    }
    next();
    return buff.join("");
}

function parseFloat1(str, radix)
{
    var parts = str.split(".");
    if ( parts.length > 1 )
    {
        return parseInt(parts[0], radix) + parseInt(parts[1], radix) / Math.pow(radix, parts[1].length);
    }
    return parseInt(parts[0], radix);
}

function read_numeral(curr, next){
    var first = curr();
    next();
    var hex = true;
    if (first == '0' && (curr() == 'x' || curr() == 'X')){   /* hexadecimal? */
        next();
        var buff=[first];
        var ch = curr();
        var prev = first;
        while (lishexdigit(ch) || ch == '.' || ch == 'e' || (prev == 'e' && ch == '-')){
            buff.push(ch);
            next();
            prev = ch;
            ch = curr();
        }
        return parseFloat1(buff.join(""), 16);
        //throw new Error("Hexadecimal numeric not supported in lua.js yet.");
    } else {
        var buff = [first];
        var ch = curr();
        var prev = first;
        while (lisdigit(ch) || ch == '.' || ch == 'e' || (prev == 'e' && ch == '-')){
            buff.push(ch);
            next();
            prev = ch;
            ch = curr();
        }

        //not TODO: use locale decimal point.
        return parseFloat(buff.join(""));
    }
}

function read_identifier_name(curr, next){
    var buff = [];
    while (lislalnum(curr())){
        buff.push(curr());
        next();
    }
    return buff.join("");
}

function is_reserved(name){
    return typeof(reserved[name]) == 'number' && reserved[name];
}

function llex(curr, next){
    for (;;){
        switch(curr()){
            case '\n': case '\r':
            case ' ': case '\f': case '\t': case '\t':next();break;
            case '-':{
                /* '-' or '--' (comment) */
                next();
                if (curr() != '-') {
                    return '-';
                }
                /* else is a comment */
                next();
                var ch = curr();
                if (ch == '[') {        /* long comment? */
                    var sep = skip_sep(curr, next);
                    if (sep >= 0){
                        read_long_string(curr, next, sep);    /* skip long comment */
                        break;
                    }
                }

                /* else short comment */
                while (ch && ch != "\n" && ch != "\r"){
                    /* skip until end of line (or end of file) */
                    next();
                    ch = curr();
                }
                break;
            }
            case '[':{
                /* long string or simply '[' */
                var sep = skip_sep(curr, next);
                if (sep >= 0){
                    return {
                        id: TK.TK_STRING,
                        val: read_long_string(curr, next, sep)
                    };
                } else if (sep == -1){
                    return '[';
                } else {
                    throw "invalid long string delimiter";
                }
            }
            case '=':{
                next();
                if (curr()!= '=') {
                    return '=';
                } else {
                    next();
                    return TK.TK_EQ;
                }
            }
            case '<':{
                next();
                if (curr()!= '=') {
                    return '<';
                } else {
                    next();
                    return TK.TK_LE;
                }
            }
            case '>':{
                next();
                if (curr()!= '=') {
                    return '>';
                } else {
                    next();
                    return TK.TK_GE;
                }
            }
            case '~':{
                next();
                if (curr()!= '=') {
                    return '~';
                } else {
                    next();
                    return TK.TK_NE;
                }
            }
            case ':': {
                next();
                if (curr() != ':'){
                    return ':';
                } else {
                    next(ls);
                    return TK.TK_DBCOLON;
                }
            }
            case '"': case '\'': {  /* short literal strings */
                return {
                    id: TK.TK_STRING,
                    val: read_string(curr, next)
                };
            }
            case '.': {  /* '.', '..', '...', or number */
                next();
                if (curr() == ".") {
                    next();
                    if (curr() ==  ".")
                    {
                        next();
                        return TK.TK_DOTS;/* '...' */
                    }
                    else return TK.TK_CONCAT;   /* '..' */
                }
                else if (!lisdigit(curr())) return '.';
                /* else go through */
            }
            case '0': case '1': case '2': case '3': case '4':
            case '5': case '6': case '7': case '8': case '9':
            {
                return {
                    id: TK.TK_NUMBER,
                    val: read_numeral(curr, next)
                };
            }
            case null:{
                return TK.TK_EOS;
            }
            default:{
                if (lislalpha(curr())){
                    var str = read_identifier_name(curr, next);
                    var reserved = is_reserved(str);
                    if (reserved){
                        return reserved;
                    }
                    return {
                        id: TK.TK_NAME,
                        val: str
                    };
                } else {
                    /* single-char tokens (+ - / ...) */
                    var ret = curr();
                    next();
                    return ret;
                }
            }
        }
    }
}

function generator(s){
    var cur = 0;
    function curr(){
        if (cur < s.length){
            return s.charAt(cur);
        }
        return null;
    }
    function next(){
        if (cur < s.length){
            ++cur;
        }
    }

    return function(){
        return llex(curr, next);
    }
}
exports.generator = generator;

function lex(s){
    var gen = generator(s);
    var curr = gen();
    var next = gen();
    return {
        curr: function(){
            return curr;
        },
        lookAhead: function(){
            return next;
        },
        next: function(){
            curr = next;
            next = gen();
        }
    }
}
exports.lex = lex;

},{}],8:[function(require,module,exports){
/**
 * Created by Yun on 2014/9/23.
 */

var liblex = require("./lex.js");
var lex = liblex.lex;
var TK = liblex.TK;
var tokenNames = liblex.tokens;

function tokentype(sym){
    switch (typeof(sym)) {
        case 'string':
        case 'number':
            return sym;
        case 'object':
            return sym.id;
    }
}

function tokenName(sym){
    if (typeof(sym) == 'number'){
        return tokenNames[sym];
    } else if (typeof(sym) == 'object') {
        return tokenNames[sym.id];
    } else {
        return sym;
    }
}

function singlevar(s){
    check(s, TK.TK_NAME);
    var ret = s.curr().val;
    s.next();
    return {
        type: "variable",
        val: ret
    };
}

function primaryexp(s){
    var t = tokentype(s.curr())
    switch(t){
        case '(':{
            s.next();
            var exp = expr(s);
            checknext(s, ')');
            return {
                type: "expr.brackets",
                "expr": exp
            };
        }
        case TK.TK_NAME:{
            return singlevar(s);
        }
        case TK.TK_JAVASCRIPT:{
            s.next();
            return {
                type: "expr.javascript",
                "args": funcargs(s)
            }
        }
        default:{
            throw new Error("unexpected symbol " + (tokenNames[t] || t));
        }
    }
}

function testnext(s, expected){
    if (tokentype(s.curr()) == expected){
        s.next();
        return true;
    }
    //return false;
}

function check(s, expected){
    if (tokentype(s.curr()) != expected){
        throw new Error("symbol "+tokenName(expected)+" expected!");
    }
}

function checknext(s, val){
    check(s, val);
    s.next();
}

function str_checkname(s){
    check(s, TK.TK_NAME);
    var ret = s.curr().val;
    s.next();
    return ret;
}

function checkname(s){
    return {
        type: "const.string",
        val: str_checkname(s)
    };
}

function codestring(s){
    check(s, TK.TK_STRING);
    var ret = s.curr().val;
    s.next();
    return {
        type: "const.string",
        val: ret
    };
}

function yindex(s){
    s.next(); /* skip the '[' */
    var exp = expr(s);
    checknext(s, ']');
    return exp;
}

function funcargs(s){
    switch (tokentype(s.curr())){
        case '(':{
            s.next();
            if (s.curr() == ')') {  /* arg list is empty? */
                s.next();
                return [];
            } else {
                var args = explist(s);
                checknext(s, ')');
                return args;
            }
        }
        case '{':{
            return [constructor(s)];
        }
        case TK.TK_STRING:{
            return [codestring(s)];
        }
        default:{
            throw new Error("function arguments expected, got "+ tokenName(s.curr()));
        }
    }
}

function suffixedexp(s){
    var primary = primaryexp(s);
    for (;;) {
        switch(tokentype(s.curr())){
            case '.':{
                s.next();
                var key = checkname(s);
                primary = {
                    "type": "expr.index",
                    "self": primary,
                    "key": key
                };
                break;
            }
            case '[':{
                var key = yindex(s);
                primary = {
                    "type": "expr.index",
                    "self": primary,
                    "key": key
                };
                break;
            }
            case ':':{
                s.next();
                var key = checkname(s);
                var args = funcargs(s);
                primary = {
                    "type": "expr.callMethod",
                    "self": primary,
                    "key": key,
                    "args": args
                }
                break;
            }
            case '(': case '{':case TK.TK_STRING:{
                var args = funcargs(s);
                primary =  {
                    "type": "expr.call",
                    "func": primary,
                    "args": args
                }
                break;
            }
            default:
                return primary;
        }
    }
}

function getunopr(s){
    switch (s.curr()){
        case TK.TK_NOT: return "uop.not";
        case '-': return "uop.minus";
        case '#': return "uop.len";
//        default: return null;
    }
}

function getbinopr(s){
    switch (s.curr()){
        case '+': return 1;
        case '-': return 2;
        case '*': return 3;
        case '/': return 4;
        case '%': return 5;
        case '^': return 6;
        case TK.TK_CONCAT: return 7;
        case TK.TK_EQ: return 8;
        case '<': return 9;
        case TK.TK_LE: return 10;
        case TK.TK_NE: return 11;
        case '>': return 12;
        case TK.TK_GE: return 13;
        case TK.TK_AND: return 14;
        case TK.TK_OR: return 15;
//        default: return null;
    }
}

function simpleexp(s){
    switch (tokentype(s.curr())){
        case TK.TK_NUMBER:{
            var val = s.curr().val;
            s.next();
            return {
                type: "const.number",
                val: val
            }
        }
        case TK.TK_STRING:{
            return codestring(s);
        }
        case TK.TK_NIL: {
            s.next();
            return {
                type: "const.nil"
            }
        }
        case TK.TK_TRUE:{
            s.next();
            return {
                type: "const.boolean",
                val: true
            }
        }
        case TK.TK_FALSE:{
            s.next();
            return {
                type: "const.boolean",
                val: false
            }
        }
        case TK.TK_DOTS: { /* vararg */
            s.next();
            return {
                type: "vararg"
            }
        }
        case '{': {
            return constructor(s);
        }
        case TK.TK_FUNCTION:{
            s.next();
            return body(s);
        }
        default: {
            return suffixedexp(s);
        }
    }
}

var priority = [
    null,
    [6, 6], [6, 6], [7, 7], [7, 7], [7, 7],  /* `+' `-' `*' `/' `%' */
    [10, 9], [5, 4],                 /* ^, .. (right associative) */
    [3, 3], [3, 3], [3, 3],          /* ==, <, <= */
    [3, 3], [3, 3], [3, 3],          /* ~=, >, >= */
    [2, 2], [1, 1]                   /* and, or */
];

var opname = [
    null,
    "op.add", "op.minus", "op.mul", "op.div", "op.mod",
    "op.pow", "op.concat",
    "op.equal", "op.less", "op.lessequal",
    "op.notequal", "op.great", "op.greatequal",
    "op.and", "op.or"
]

exports.opname = opname;

var UNARY_PRIORITY = 8;

function subexpr(s, limit){
    var ret;
    var uop = getunopr(s);
    if (uop) {
        s.next();
        ret = subexpr(s, UNARY_PRIORITY);
        ret = {
            type: 'expr.uop',
            op: uop,
            operand: ret
        }
    } else {
        ret = simpleexp(s);
    }
    var op = getbinopr(s);
    while (op && priority[op][0] > limit){
        s.next();
        var e2 = subexpr(s, priority[op][1]);
        ret = {
            type: 'expr.op',
            op: opname[op],
            left: ret,
            right: e2
        }

        op = getbinopr(s);
    }
    return ret;
}

function expr(s){
    return subexpr(s, 0);
}

function explist(s){
    var exps = [];
    exps.push(expr(s));
    while (testnext(s, ',')){
        exps.push(expr(s));
    }
    return exps;
}

function assignment(s, lefts){
    while (testnext(s, ',')){
        lefts.push(suffixedexp(s));
    }
    checknext(s, '=');
    return {
        type: "stat.assignment",
        lefts: lefts,
        right: explist(s)
    }
}

function exprstat(s){
    var exp1 = suffixedexp(s);
    if (s.curr() == '=' || s.curr() == ',') {
        return assignment(s, [exp1]);
    } else {
        if (exp1.type != "expr.call" && exp1.type != "expr.callMethod" && exp1.type != "expr.javascript"){
            throw new Error("syntax error, unexpected expr type "+exp1.type);
        }
        return {
            "type": "stat.expr",
            "expr": exp1
        };
    }
}

function listfield(s){
    return {
        "type": "field.list",
        "val": expr(s)
    }
}

function recfield(s){
    var key;
    if (tokentype(s.curr()) == TK.TK_NAME){
        key = checkname(s);
    } else {
        key = yindex(s);
    }

    checknext(s, '=');
    return {
        "type": "field.rec",
        "key": key,
        "val": expr(s)
    }
}

function field(s){
    var curr = s.curr();
    switch (tokentype(curr)){
        case TK.TK_NAME:{
            if (s.lookAhead() != '=') {
                return listfield(s);
            } else {
                return recfield(s);
            }
        }
        case '[': {
            return recfield(s);
        }
        default: {
            return listfield(s);
        }
    }
}

function constructor(s){
    checknext(s, '{');

    var fields = [];

    do {
        if (s.curr() == '}') break;
        var fi = field(s);
        if (fi){
            fields.push(fi);
        }
    } while (testnext(s, ',') || testnext(s, ';'));

    checknext(s, '}');

    return {
        "type": "expr.constructor",
        "fields": fields
    }
}

function test_then_block(s, target){
    target.cond = expr(s);
    checknext(s, TK.TK_THEN);
    target.tblock = block(s);
}

function ifstat(s){
    var root = {
        type: "stat.if"
    }
    var current = root;

    s.next(); //skip if
    test_then_block(s, current);
    while (testnext(s, TK.TK_ELSEIF)) {     /*elseif */
        current.fblock = {
            type: "block",
            stats: [
                {
                    type: "stat.if"
                }
            ]
        }
        current = current.fblock.stats[0];
        test_then_block(s, current);
    }
    if (testnext(s, TK.TK_ELSE)){
        current.fblock = block(s);
    }
    checknext(s, TK.TK_END);
    return root;
}

function whilestat(s){
    s.next(); // skip while
    var cond = expr(s);
    checknext(s, TK.TK_DO);
    var blk = block(s);
    checknext(s, TK.TK_END);
    return {
        type: "stat.while",
        cond: cond,
        block: blk
    }
}

function fornum(s, varname){
    s.next(); //skip '='
    var from = expr(s);
    checknext(s, ',');
    var to = expr(s);
    var step;
    if (testnext(s, ',')) {
        step = expr(s);
    }

    return {
        type: "stat.fornum",
        varname: varname,
        from: from,
        to: to,
        step: step
    }
}

function forlist(s, varnames){
    while (testnext(s, ',')){
        varnames.push(str_checkname(s));
    }
    checknext(s, TK.TK_IN);
    return {
        type: "stat.forlist",
        varnames: varnames,
        explist: explist(s)
    }
}

function forstat(s){
    s.next(); // skip for;
    var varname = str_checkname(s);

    var ret;

    switch (s.curr()){
        case '=':
            ret = fornum(s, varname);
            break;
        case ',':
        case TK.TK_IN:
            ret = forlist(s, [varname]);
            break;
        default:
            throw "`=` or `in` expected"
    }
    checknext(s, TK.TK_DO);  // skip do
    ret.block = block(s);
    checknext(s, TK.TK_END);
    return ret;
}

function repeatstat(s){
    s.next();
    var b = block(s);
    checknext(s, TK.TK_UNTIL);
    //return {
    //    type: "stat.repeat",
    //    until: expr(s),
    //    block: b
    //}
    b.stats.push({
        "type": "stat.if",
        "cond": expr(s),
        "tblock": {
            "type": "stat.break",
        }
    })
    return {
        "type": "stat.while",
        "cond": {
            "type": "const.boolean",
            "val": true,
        },
        "block": b,
    }
}

function funcname(s){
    var ret = singlevar(s);
    while (testnext(s, '.')){
        var key = checkname(s);
        ret = {
            type: "expr.index",
            self: ret,
            key: key
        }
    }
    if (testnext(s, ':')) {
        var key = checkname(s);
        return {
            type: "stat.method",
            self: ret,
            key: key
        }
    } else {
        return {
            type: "stat.function",
            left: ret
        }
    }
}

function funcstat(s){
    s.next();
    var f = funcname(s);
    f.func = body(s);
    return f;
}

function localfunc(s){
    var name = str_checkname(s);
    return {
        type: "stat.localfunction",
        name: name,
        func: body(s)
    }
}

function localstat(s){
    var names = [];
    do{
        names.push(str_checkname(s));
    } while (testnext(s, ','));

    var right;
    if (testnext(s, '=')){
        right = explist(s);
    }
    return {
        type: "stat.local",
        names: names,
        right: right
    }
}

function retstat(s, isJSReturn){
    var ret = {
        type: isJSReturn ? 'stat.jsreturn' : "stat.return",
        nret: []
    };
    s.next();
    if (block_follow(s) || s.curr() == ';'){
    } else {
        ret.nret = explist(s);
    }

    //skip all ';' after return
    while (testnext(s, ';')){
    }

    return ret;
}

function statement(s){
    var curr = s.curr();
    switch(curr){
        case ';': { /* stat -> ';' (empty statement) */
            s.next();   /* skip ';' */
            break;
        }
        //TODO:
        case TK.TK_IF:
            return ifstat(s);
        case TK.TK_WHILE:
            return whilestat(s);
        case TK.TK_DO:{
            s.next();
            var ret = block(s);
            checknext(s, TK.TK_END);
            return ret;
        }
        case TK.TK_FOR:
            return forstat(s);
        case TK.TK_REPEAT:
            return repeatstat(s);
        case TK.TK_FUNCTION:
            return funcstat(s);
        case TK.TK_LOCAL:{
            s.next();
            if (testnext(s, TK.TK_FUNCTION)){
                return localfunc(s);
            } else {
                return localstat(s);
            }
        }
        case TK.TK_RETURN: {
            return retstat(s);
        }
        case TK.TK_JSRETURN:{
            return retstat(s, true);
        }
        case TK.TK_BREAK: {
            s.next()
            return {
                type:"stat.break"
            }
        }

//        case TK.TK_DBCOLON:
//        case TK.TK_GOTO:

        default:{
            return exprstat(s);
        }
    }
}

function block_follow(s){
    switch (s.curr()){
        case TK.TK_ELSE:
        case TK.TK_ELSEIF:
        case TK.TK_END:
        case TK.TK_EOS:
        case TK.TK_UNTIL:
            return true;
        default:
            return 0;
    }
}

function statlist(s){
    var ret = [];
    while (!block_follow(s)){
        if (s.curr() == TK.TK_RETURN || s.curr() == TK.TK_JSRETURN){
            ret.push(statement(s));
            break;
        }
        var stat = statement(s);
        if (stat) {
            ret.push(stat);
        }
    }
    return ret;
}

function block(s){
    return {
        type: 'block',
        stats: statlist(s)
    }
}

function parlist(s){
    var ret = [];
    if (s.curr() != ')'){
        do {
            switch (tokentype(s.curr())){
                case TK.TK_NAME:{
                    ret.push(str_checkname(s));
                    break;
                }
                case TK.TK_DOTS:{
                    ret.push(TK.TK_DOTS);
                    s.next();
                    break;
                }
                default:
                    throw "<name> or `...` expected";
            }
        } while(testnext(s ,','));
    }
    return ret;
}

function body(s){
    checknext(s, '(');
    var args = parlist(s);
    var varargs = false;
    if (args.length > 0 && args[args.length - 1] == TK.TK_DOTS) {
        args.pop();
        varargs = true;
    }
    checknext(s, ')');
    var body = block(s);
    checknext(s, TK.TK_END);
    return {
        type: 'function',
        args: args,
        varargs: varargs,
        block: body
    }
}

function main(s){
    var ret = {
        type: "function",
        args: [],
        varargs: true,
        block: block(s)
    };
    check(s, TK.TK_EOS);
    return ret;
}
exports.main = main;

function parse(s){
    return exports.main(lex(s));
}
exports.parse = parse;

},{"./lex.js":7}],9:[function(require,module,exports){
/**
 * Created by Yun on 2014/9/23.
 */

var dummy0 = {
    _hashKey: -1,
    valueOf:function(){return 0;},
    toString:function(){return "0";}
};
function dstype(){
    this._hashKey = -2;
    this.toString = function(){return "";}
}
dstype.prototype = String.prototype;
var dummyStr = new dstype();

exports.dummy0 = dummy0;
exports.dummyStr = dummyStr;

var _hashKeyId = 0;

function LuaTable(fields){
    this.stringMap = {};
    this.array = [];
    this.hashMap = {};
    this.metatable = null;

    this._hashKey = ++ _hashKeyId;

    this._linkHead = null;
    this._linkTail = null;

    if (fields){
        for (var i = 0 ;i < fields.length; i++){
            var v = fields[i];
            if (v[0] == 0){
                this.array.push(v[1]);
            } else if (v[0] == 1) {
                this.set(v[1],v[2]);
            } else {
                for (var j = 0; j < v[1].length; j++){
                    this.array.push(v[1][j]);
                }
            }
        }
    }
}
exports.LuaTable = LuaTable;

exports.newHashKey = function(){
    return ++ _hashKeyId;
}
LuaTable.prototype = {};

LuaTable.prototype.constructor = LuaTable;

LuaTable.prototype.get = function(k){
    switch(typeof(k)){
        case 'number':
            return this.array[k-1];
        case 'string':
            var rec = this.stringMap[k];
            return rec && rec[1];
        case 'object':
            if (k === dummy0){
                return this.array[-1];
            }
            if (k === dummyStr){
                var rec = this.stringMap[k];
                return rec && rec[1];
            }
            if (k === null){
                throw new Error("table index is nil");
            }
        case 'function':{
            if (!k._hashKey) {
                //throw new Error("get with a invalid object" + k);
                k._hashKey = ++ _hashKeyId;
            }
            var rec = this.hashMap[k._hashKey];
            return rec && rec[1];
        }
        default:{
            throw new Error("get with a invalid argument" + k);
        }
    }
}

LuaTable.prototype.getRec = function(k) {
    if (typeof(k) === 'string' ){
        return this.stringMap[k];
    } else {
        return this.hashMap[k];
    }
}

LuaTable.prototype.addToLink = function(k, rec){
    if (this._linkHead === null) {
        this._linkHead = this._linkTail = k;
        rec[2] = rec[3] = null;
    } else {
        var last = this.getRec(this._linkTail);
        last[3] = k;
        rec[2] = this._linkTail;
        rec[3] = null;
        this._linkTail = k;
    }
}

LuaTable.prototype.removeFromLink = function(k, rec){
    if (!rec){
        return;
    }
    var prev = rec[2] && this.getRec(rec[2]);
    var next = rec[3] && this.getRec(rec[3]);

    if (prev) {
        prev[3] = rec[3];
    } else {
        this._linkHead = rec[3];
    }
    if (next){
        next[2] = rec[2];
    } else {
        this._linkTail = rec[2];
    }
}

LuaTable.prototype.set = function(k, v){
    if (k == null){
        throw new Error("table index is nil");
    }
    if (v == null){
        switch(typeof(k)){
            case 'number':
                if (k == this.array.length){
                    this.array.pop();
                } else {
                    delete this.array[k-1];
                }
                break;
            case 'string':
                this.removeFromLink(k, this.stringMap[k]);
                delete this.stringMap[k];
                break;
            case 'object':case 'function':{
                if (!k._hashKey) {
                    // ignore object that is not a key.
                    return;
                }
                this.removeFromLink(k._hashKey, this.hashMap[k._hashKey]);
                delete this.hashMap[k._hashKey];
                break;
            }
            default:{
                throw new Error("set with a invalid argument" + k);
            }
        }
        return;
    }
    switch(typeof(k)){
        case 'number':
            this.array[k-1] = v;
            break;
        case 'string':
            if (this.stringMap[k]) {
                this.stringMap[k][1] = v;
            } else {
                this.stringMap[k] = [k, v];
                this.addToLink(k, this.stringMap[k]);
            }
            break;
        case 'object':case 'function':{
            if (!k._hashKey) {
                k._hashKey = ++ _hashKeyId;
                //throw new Error("set with a invalid object" + k);
            }
            if (this.hashMap[k._hashKey]) {
                this.hashMap[k._hashKey][1] = v;
            } else {
                this.hashMap[k._hashKey] = [k, v];
                this.addToLink(k._hashKey, this.hashMap[k._hashKey]);
            }
            break;
        }
        default:{
            throw new Error("set with a invalid argument" + k);
        }
    }
}

LuaTable.prototype.length = function(){
    var len = this.array.length;
    for (; len > 0 && this.array[len-1] == null; --len){}
    if (len != this.array.length){
        this.array.length = len;
    }

    return this.array.length;
}

LuaTable.prototype.toString = function() {
    return ("table " + this._hashKey);
}

LuaTable.prototype.nextKey = function(k) {
    if (k == null){
        k = 0;  //try from start.
    }
    switch (typeof(k)){
        case 'number':
            for (;k < this.array.length;++k){
                if (this.array[k] != null) {
                    return k+1;
                }
            }
            if (this._linkHead === null){
                return null;
            }
            return this.getRec(this._linkHead)[0];
        case 'string':
            var k = this.getRec(k)[3];
            if (k == null){
                return null;
            }
            return this.getRec(k)[0];
        case 'object': case 'function': {
            var k = this.getRec(k._hashKey)[3];
            if (k == null){
                return null;
            }
            return this.getRec(k)[0];
        };
        default: {
            return null;
        }
    }
}

},{}],10:[function(require,module,exports){
(function (process){(function (){
var path = require( "path" )
var fs = require( "fs" )

var PMC = {}

// Plugin Class
var { ActivePlugin, RePackMcPlugin } = require( "./src/Plugin.js" )
PMC.ActivePlugin = ActivePlugin
PMC.RePackMcPlugin = RePackMcPlugin

// Default Plugin
var {Event, TickEvent} = require( "./src/napi/Event" )
PMC.Recipe = require( "./src/napi/Recipe" )
PMC.Function = require( "./src/napi/Function" )
PMC.Block = require( "./src/napi/Block" )
PMC.Loot = require( "./src/napi/Loot" )
PMC.Vanilla = require( "./src/napi/Vanilla/Vanilla" )
PMC.Minecraft = require( "./src/ActiveCore/Minecraft" )
PMC.isMinecraftRunTime = PMC.Minecraft.isMinecraftRunTime
PMC.Event = Event
PMC.TickEvent = TickEvent
PMC.EventEmitterType = {
  List: "sequence", Rand: "randomize"
}
PMC.Item = class extends PMC.RePackMcPlugin {
  constructor( ctx ){
    super( "Item", ctx, require( "./src/oapi/item" ) )
    ctx.Items = []
    ctx.Item = ( name, option = {}, createFile = true ) => {
      var item = this.callMethod( createFile, ctx.namespace + ":item" + ctx.Items.length, "item" + ctx.Items.length, name, option.type || "equipment" )
      var jump = [ "type" ]
      for( let key of Object.keys( option ) ){
        if( jump.includes( key ) ) continue;
        item.set( key, option[key] )
      }
      if( createFile ){
        console.log( "Tip: 物品" + name + "的贴图路径为 Addon目录/resources/textures/items/item" + ctx.Items.length + ".(png|jpg)" )
        if( this.file( "resources/textures/item_texture.json" ) ){
          var json = JSON.parse(this.read( "resources/textures/item_texture.json" ))
          json.texture_data[ "item" + ctx.Items.length ] = { textures: "textures/items/item" + ctx.Items.length }
          this.write( "resources/textures/item_texture.json", JSON.stringify( json, 0, 2 ) )
        } else {
          var json = {texture_data: {}}
          json.texture_data[ "item" + ctx.Items.length ] = { textures: "textures/items/item" + ctx.Items.length }
          this.write( "resources/textures/item_texture.json", JSON.stringify( json, 0, 2 ) )
        }
        ctx.Items.push( name )
      }
      return item
    }
  }
}

// Context
PMC.DefaultEntry = "scripts/index.js"
PMC.Context = class {
  constructor( addon ){
    this.dir = addon.dir
    this.namespace = addon.ns
    this.addon = addon
    this.entry = addon.entry
    this.scripePath = addon.scriptPackAt
    this.modules = addon.smodules
    this.plugins = {}
    this.loadActivePlugin( PMC.Item )
    this.loadActivePlugin( PMC.Event )
    this.loadActivePlugin( PMC.Recipe )
    this.loadActivePlugin( PMC.Function )
    this.loadActivePlugin( PMC.Vanilla )
    this.loadActivePlugin( PMC.Block )
    this.loadActivePlugin( PMC.Loot )
  }
  onMinecraft( callback ){
    if( PMC.isMinecraftRunTime ) callback( PMC.Minecraft )
  }
  onGenerate(){
  
  }
  generate(){
    for( let key of Object.keys( this.plugins ) ){
      this.plugins[key].onGenerate()
      // if( PMC.isMinecraftRunTime ) this.plugins[key].onMinecraft( PMC.Minecrat )
    }
    if( this.entry && !PMC.isMinecraftRunTime ){
      var {execSync} = require( "child_process" ), outputPath, append = ""
      execSync( "browserify '" + process.argv[1] + "' -o '" + (outputPath = path.join( path.join(this.dir, this.scripePath ), this.entry)) + "'" )
      for( let module of this.modules ){
        let name = path.basename( module )
        append += "import * as $" + name.replaceAll( "-", "_" ) + " from '" + module + "'\n"
      }
      append += "var __dirname = ''\nvar __filename = 'index.js';\n"
      if( typeof PMC._rvfs == "object" && !PMC.isMinecraftRunTime ){
        append += "var $_vfs = " + JSON.stringify( PMC._rvfs, 0, 2 ) + ";"
      }
      fs.writeFileSync( outputPath,
        append + fs.readFileSync( outputPath ).toString())
    }
    this.onGenerate()
  }
  loadActivePlugin( Plugin ){
    var plugin = new Plugin( this )
    this.plugins[plugin.define] = plugin
    if( PMC.isMinecraftRunTime ) plugin.onMinecraft( PMC.Minecraft )
  }
}

PMC.Addon = class {
  constructor( manifest, dir, json = true ){
    this.dir = dir
    this.ns = "mod"
    this.entry = false
    this.scriptPackAt = "data/"
    this.smodules = [ "@minecraft/server" ]
    if( json ) throw "暂不支持生成Manifest"
  }
  followLoveKogasaAtBiliOrX(){
    // 彩蛋函数
    console.log( "Thank You!" )
  }
  loadResources( dir, vdir = "." ){
    if( !PMC.isMinecraftRunTime ){
      if( typeof PMC._rvfs != "object" ) PMC._rvfs = {}
      var files = fs.readdirSync( dir, {recursive : true} )
      for( let fn of files ){
        if( fs.statSync( path.join( dir, fn ) ).isFile() ){
          PMC._rvfs[path.join( vdir, fn )] = fs.readFileSync( path.join( dir, fn ) ).toString()
        } else {
          PMC._rvfs[path.join( vdir, fn )] = true
        }
      }
    }
  }
  getAddonCtx(){
    return (this.ctx = new PMC.Context( this ))
  }
  setEntry( entry = PMC.DefaultEntry ){
    this.entry = entry
    return entry
  }
  setEntryPack( dir ){
    this.scriptPackAt = dir
    return this
  }
  requireModule( name ){
    this.smodules.push( name )
    return this
  }
  generate(){
    if( this.ctx ){
      return this.ctx.generate()
    }
  }
  setNamespace( ns ){ this.ns = ns }
  static fromJSON( dir ){
    return new PMC.Addon({}, dir, false)
  }
}

module.exports = PMC
}).call(this)}).call(this,require('_process'))
},{"./src/ActiveCore/Minecraft":11,"./src/Plugin.js":13,"./src/napi/Block":15,"./src/napi/Event":16,"./src/napi/Function":17,"./src/napi/Loot":18,"./src/napi/Recipe":19,"./src/napi/Vanilla/Vanilla":26,"./src/oapi/item":28,"_process":3,"child_process":1,"fs":1,"path":2}],11:[function(require,module,exports){
var Minecraft = {
  server: typeof $server == "object"
    ? $server : { world: {
      sendMessage( message ){ return void 0 }
    }},
  serverUi: typeof $server_ui == "object"
    ? $server_ui : {},
  isMinecraftRunTime: typeof $server == "object",
  fs: require( "./VirtualFileSystem" )
}
Minecraft.print = (...string) => Minecraft.server.world.sendMessage(...string)
Minecraft.world = Minecraft.server.world
module.exports = Minecraft

},{"./VirtualFileSystem":12}],12:[function(require,module,exports){
var p = require( "path" )
module.exports = {
  _vDir: typeof $_vfs == "object" ? $_vfs : {},
  virtual: true,
  existsSync( path ){
    return !!this._vDir[p.join(".", path)]
  },
  readFileSync( path ){
    if( this._vDir[p.join(".", path)] ) return this._vDir[path]
    throw "No such file or directory"
  },
  writeFileSync( path, data ){
    return this._vDir[p.join(".", path)] = data
  },
  mkdirSync( path ){
    return this._vDir[p.join(".", path)] = true
  },
  appendFileSync( path ){
    return this._vDir[p.join(".", path)] += data
  },
  readdirSync( path ){
    var output = []
    for( let filePath in this._vDir ){
      if( p.dirname(filePath) == path ) output.push( filePath )
    }
    return output
  },
  rmSync( path, options ){
    var data = this._vDir[p.join(".", path)]
    if( options.recursive ){
      for( let p in this._vDir ){
        if( p.includes( path ) ) delete this._vDir[p]
      }
    }
    delete this._vDir[path]
    return data
  },
  bindFileSystem( fsObject ){
    Object.assign( this._vDir, fsObject )
    return this
  }
}
},{"path":2}],13:[function(require,module,exports){
var fs = require( "fs" )
var path = require( "path" )
// For browserify
if( !fs.readFileSync ) fs = require( "./ActiveCore/VirtualFileSystem" )

// Plugin class
class ActivePlugin {
  constructor( define, mcctx ){
    this.define = define
    this.ctx = mcctx
  }
  // fileSystem
  read( name, error = console.error ){
    try {
      return fs.readFileSync( path.join( this.ctx.dir, name ) )
    } catch( err ){
      error( err )
    }
  }
  write( name, data, error = console.error ){
    try {
      // 偷懒(
      if( this.file( name.split( "/" ).slice( 0, -1 ).join( "/" ) ) || fs.virtual ){
        return fs.writeFileSync( path.join( this.ctx.dir, name ), data )
      } else {
        mkdirsSync( path.join( this.ctx.dir, name.split( "/" ).slice( 0, -1 ).join( "/" )) )
        this.write( name, data, error )
      }
    } catch( err ){
      error( err )
    }
  }
  file( p ){ return fs.existsSync( path.join(this.ctx.dir, p) ) }
  json( p, callback ){
    if( !this.file(p) ) this.write( p, "{}" )
    var data = JSON.parse(this.read(p) || "{}")
    callback( data )
    this.write( p, JSON.stringify( data, 0, 2 ) )
    return data
  }
  // Utils
  subId( id ){
    return id.split(":")[1]
  }
  // Events
  onGenerate(){
  
  }
  onMinecraft( mc ){
  
  }
}

// For old core
class RePackMcPlugin extends ActivePlugin {
  constructor( define, ctx, func ){
    super( define, ctx )
    this.func = func
    this.files = []
  }
  callMethod( createFile = true, ...args ){
    var otp = this.func( ...args )
    if( createFile )this.files.push( otp )
    return otp
  }
  onGenerate(){
    for( let ovapi of this.files ){
      let files = ovapi.json()
      for( let file of files ){
        this.write( file.path, file.isjson === false ? file.json : JSON.stringify( file.json, 0, 2 ) )
      }
    }
  }
}

// For sapdon core
class SapdonPlugin extends ActivePlugin {
  constructor( define, ctx, object/** see @sapdon/core/class */, className ){
    super( define, ctx )
    this.fileTasks = []
    if( typeof object == "string" ){
      import( object ).then(( object ) => {
        this.object = object[className]
        this.onInit( object )
      })
    } else {
      this.object = object[className]
      this.onInit( object )
    }
  }
  callMethod( ...args ){
    var ret = new this.object(...args)
    this.fileTasks.push( ret )
    return ret
  }
  onGenerate(){
    // Sapdon Api 具有活态性(
  }
  onInit( object ){
    
  }
}

// Other method (偷懒)
function mkdirsSync(dirname) {
  if( fs.virtual ) return true
  if (fs.existsSync(dirname)) {
    return true;
  } else {
    if (mkdirsSync(path.dirname(dirname))) {
      fs.mkdirSync(dirname);
      return true;
    }
  }
}

module.exports = {ActivePlugin, RePackMcPlugin, SapdonPlugin}
},{"./ActiveCore/VirtualFileSystem":12,"fs":1,"path":2}],14:[function(require,module,exports){
class MinecraftObject {
  constructor( label, id, version = "1.16.100", namespace = "minecraft:" ){
    this.id = id
    this.label = label
    this.format = version
    this.component = void 0
    this.event = void 0
    this.conditions = void 0
    this.body = {}
    this.namespace = namespace
  }
  json(){
    var json = {
      "format_version": this.format,
      [this.namespace + this.label]: {
        description: { identifier: this.id },
        ...this.body
      }
    }
    if( typeof this.component == "object" ){
      json["minecraft:" + this.label].components = this.component
    }
    if( typeof this.event == "object" ){
      json["minecraft:" + this.label].events = this.event
    }
    if( typeof this.conditions == "object" ){
      json["minecraft:" + this.label].conditions = this.conditions
    }
    this.onGenerateJSON( json )
    return json
  }
  initComponent(obj = {}){
    this.component = obj
    return this
  }
  initEvent(obj = {}){
    this.event = obj
    return this
  }
  initCondition( array ){
    this.conditions = array
    return this
  }
  set(key, value, namespace = "minecraft:"){
    this.component[namespace + key] = value
    return this
  }
  setEvent( key, value ){
    this.event[key] = value
    return this
  }
  condition( rule ){
    this.conditions.push( rule )
    return this
  }
  subId(){
    return this.id.split( ":" )[1]
  }
  // Events
  onGenerateJSON( json ){
    
  }
}

Object.prototype.each = function( callback ){
  var loop = true
  for( let key of Object.keys( this ) ){
    if( loop ){
      callback( this[key], key, () => (loop = false), this )
    } else return;
  }
}

Object.prototype.jsonify = function( tab = 2 ){
  return JSON.stringify( this, 0, 2 )
}

String.prototype.jsonify = function(){
  return JSON.parse( this )
}

module.exports = {MinecraftObject}
},{}],15:[function(require,module,exports){
var {ActivePlugin} = require( "../Plugin" )
var {MinecraftObject: McObj} = require( "../Util" )

class Block {
  constructor( id, name, texture = 1, i18n ){
    this.object = new McObj( "block", id )
    this.category = "nature"
    this.group = void 0
    this.id = id, this.name = name
    this.texture = texture
    this.sound = "stone"
    this.i18n = i18n
    this.name = name
    i18n.t( "tile." + this.object.subId() + ".name", name )
    this.object.onGenerateJSON = ( json ) => {
      json[ "minecraft:block" ].description.menu_category = {
        category: this.category
      }
      if( this.group ) json[ "minecraft:block" ].description.menu_category.group = this.group
    }
    this.object.initComponent({
      "minecraft:display_name": this.object.subId(),
      "minecraft:destroy_time": 0.5,
      "minecraft:map_color": "#000000",
      "minecraft:material_instances": {
        "*": { "texture": id }
      }
    })
  }
  extend( block, texture = false ){
    block.object.component.each((value, key) => {
      this.object.component[key] = value
    })
    this.rename( block.name )
    if( texture ) this.texture = block.texture
    this.sound = block.sound
    return this
  }
  setCategory( type ){
    this.category = type
    return this
  }
  setGroup( type ){
    this.group = type
    return this
  }
  set( k, v ){
    this.object.set( k, v )
    return this
  }
  get( k, namespace = "minecraft:" ){
    return this.object.component[namespace + k]
  }
  getId(){
    return this.id
  }
  toString(){
    return this.getId()
  }
  setSound( s ){
    this.sound = s
  }
  rename( name ){
    this.name = name
    i18n.t( "tile." + this.object.subId() + ".name", name )
  }
  event( k, v ){
    if( !this.object.event ) this.object.initEvent()
    if( v ){
      this.object.setEvent( k, v )
      return this
    } else return this.object.event[k]
  }
  jsonify(){
    return this.object.json()
  }
}

class BlockPlugin extends ActivePlugin {
  constructor( ctx ){
    super( "Block", ctx )
    if( !ctx.plugins.i18n ) ctx.loadActivePlugin( require( "./i18n" ) )
    this.blocks = []
    this.i18n = ctx.plugins.i18n.new( "en_US" )
    ctx.Block = ( name, config ) => this.createBlock( name, config )
    ctx.BlockTexture = {
      All: 1, Side: 2, TopBottomAndSide: 3,
      Face: 6
    }
  }
  createBlock( name, config = {}, f = true ){
    var block = new Block( this.ctx.namespace + ":block" + this.blocks.length, name, 1, this.i18n )
    var spacialTag = ["texture"]
    if( f ) this.blocks.push( block )
    config.each(function( value, key, stop ){
      if(!spacialTag.includes(key)){
        block.set( key, value )
      } else if( key = "texture" ){
        block.texture = value
      }
    })
    return block
  }
  onGenerate(){
    this.blocks.forEach(( v, k, a ) => {
      this.write( "data/blocks/" + v.object.subId() + ".json", v.jsonify().jsonify() )
      var textureList = []
      this.json( "resources/blocks.json", ( data ) => {
        var textures = {}
        if( v.texture == 1 ){
          textures = v.object.subId()
          textureList.push( textures )
        } else if( v.texture == 2 ){
          textures = {
            up: v.object.subId() + "_top",
            down: v.object.subId() + "_top",
            side: v.object.subId() + "_side"
          }
          textureList.push( v.object.subId() + "_top" )
          textureList.push( v.object.subId() + "_side" )
        } else if( v.texture == 3 ){
          textures = {
            up: v.object.subId() + "_top",
            down: v.object.subId() + "_bottom",
            side: v.object.subId() + "_side"
          }
          textureList.push( v.object.subId() + "_top" )
          textureList.push( v.object.subId() + "_side" )
          textureList.push( v.object.subId() + "_bottom" )
        } else {
          textures = {
            up: v.object.subId() + "_top",
            down: v.object.subId() + "_bottom",
            south: v.object.subId() + "_south",
            north: v.object.subId() + "_north",
            west: v.object.subId() + "_west",
            east: v.object.subId() + "_east"
          }
          textureList.push( v.object.subId() + "_top" )
          textureList.push( v.object.subId() + "_south" )
          textureList.push( v.object.subId() + "_north" )
          textureList.push( v.object.subId() + "_west" )
          textureList.push( v.object.subId() + "_east" )
          textureList.push( v.object.subId() + "_bottom" )
        }
        data[ v.id ] = {textures, sound : v.sound}
      })
      this.json( "resources/textures/terrain_texture.json", (data) => {
        if( !data.texture_data ) data.texture_data = {}
        textureList.forEach( (id) => {
          data.texture_data[id] = {textures: "textures/blocks/" + id}
          console.log( "Tip: 方块" + v.name + "的贴图在 textures/blocks/" + id )
        })
      })
    })
  }
}

// console.log( new Block( "example:block", "block" ).jsonify())
module.exports = BlockPlugin
},{"../Plugin":13,"../Util":14,"./i18n":27}],16:[function(require,module,exports){
var {ActivePlugin} = require( "../Plugin" )

class Event extends ActivePlugin {
  constructor( ctx ){
    super( "Event", ctx )
    ctx.EventType = this.Type = {
      List: "sequence", Rand: "randomize"
    }
    ctx.Event = (cmds) => this.createEvent(
      this.Type.List,
      { run_command: {command: ([]).concat(cmds)} }
    )
  }
  createEvent( type, task ){
    var eObject = {}
    return (eObject[type] = task)
  }
}

class TickEvent extends ActivePlugin {
  constructor( ctx ){
    super( "Tick", ctx )
    this.Tick = []
    ctx.TickFunc = ( func ) => func ? this.Tick = func : this.Tick
    ctx.AppendTickFunc = ( func ) => this.Tick.concat( func )
  }
  onGenerate(){
    this.write( "data/functions/tick.json", JSON.stringify(
      {values: ctx.namespace + "_tick" }, 0, 2
    ))
    this.write( "data/functions/" + ctx.namespace + "_tick.mcfunction",
      this.Tick.join( "\n" )
    )
  }
}


module.exports = {Event, TickEvent}
},{"../Plugin":13}],17:[function(require,module,exports){

// 获取模板类
var {ActivePlugin} = require( "../Plugin" )

// 继承插件对象，旧Api则继承RePackMcPlugin
class Function extends ActivePlugin {

  // 初始化模块
  constructor( ctx ){
    // Function 是模块的名称(可用ctx.plugins.*访问)
    super( "Function", ctx )
    // 可用 this.ctx 访问 ctx
    this.functions = []
    ctx.Function = ( funcArray ) => this.createFunction( funcArray )
  }
  
  // 当包开始构建
  onGenerate(){
    for( let func of this.functions ){
      // 快速写入文件，用read读取文件，file判断文件是否存在
      this.write( "data/functions/" + func.id + ".mcfunction", func.functions.join( "\n" ) )
    }
  }
  
  // 你自己的方法
  createFunction( funcArray ){
    var func = new McFunction( this.ctx.namespace + this.functions.length, funcArray )
    this.functions.push( func )
    return func
  }
  
}

// 给上文用
class McFunction {

  constructor( id, array ){
    this.id = id
    this.functions = array
  }
  
  push( cmd ){
    this.functions.push( cmd )
    return this
  }
  
  reverse(){
    this.functions.reverse()
    return this
  }
  
  slice( f, t ){
    return this.functions.slice( f, t )
  }
  
  toString(){
    return "function " + this.id
  }
  
  cmd(){
    return this.toString()
  }
  
}

// 导出(Nodejs模式)
module.exports = Function
// 用ctx.loadActivePlugin加载插件
},{"../Plugin":13}],18:[function(require,module,exports){
var {ActivePlugin} = require( "../Plugin" )

class LootItem {
  constructor( items, count = 1, weight = 1, enchant = [] ){
    this.weight = weight
    this.item = ""
    this.functions = []
    this.data = 0
    this.count = this._countify( count )
    this.enchants = [].concat(this._enchantify( enchant ))
    this.weight = 1
    this.conditions = []
    if( items ){
      this.item = this._itemify( items.toString() )
    }
  }
  _enchantify( enchant ){
    var output = []
    if( Array.isArray( enchant ) ){
      enchant.forEach((v) => {
        if( typeof v == "string" ){
          var [name, level] = v.split( "@" )
          output.push({
            id: name, level: parseInt(level) || 1
          })
        } else if( typeof v == "object" ){
          output.push(v)
        }
      })
    } else {
      var [name, level] = enchant.split( "@" )
      output.push({
        id: name, level: parseInt(level) || 1
      })
    }
    return output
  }
  enchant( enchant ){
    this.enchants = this.enchants.concat(this._enchantify( enchant ))
    return this
  }
  _itemify( items ){
    if( items.includes( "@" )){
      var [item, data] = items.split( "@" )
      this.data = parseInt(data)
      return item
    } else {
      return items
    }
  }
  _countify( count ){
    if( typeof count == "number" ){
      // 似乎只能这样写
      return {min: count, max: count}
    } else if( typeof count == "string" ){
      var [min, max] = count.split( "-" )
      return {min, max}
    } else if( typeof count == "object" ){
      return count
    } else {
      return {min: 1, max: 1}
    }
  }
  jsonify(){
    var basicJSON = {
      type: "item",
      name: this.item,
      weight: this.weight
    }
    if( this.functions[0] || this.count.max != 1 || this.data > 0 || this.enchants[0] ){
      basicJSON.functions = this.functions
    }
    if( this.count.max != 1 ){
      basicJSON.functions.push({
        "function": "set_count",
        count: this.count
      })
    }
    if( this.data > 0 ){
      basicJSON.functions.push({
        "function": "set_data",
        data: this.data
      })
    }
    if( this.conditions[0] ){
      basicJSON.conditions = this.conditions
    }
    if( this.enchants[0] ){
      basicJSON.functions.push({
        "function": "specific_enchants",
        enchants: this.enchants
      })
    }
    return basicJSON
  }
}

class LootTable {
  constructor( item, count = 1, plugin ){
    this.name = plugin.ctx.namespace += "_loot" + plugin.loots.length
    this.plugin = plugin
    this.entries = []
    this.table = {
      pools: [{
        rolls: count,
        entries: []
      }]
    }
    if( item ){
      this.push( item )
    }
  }
  extend( path, weight = 1 ){
    this.table.pools[0].entries.push({
      type: "loot_table",
      name: path.toString(),
      weight
    })
    return this
  }
  push(...itemLoot){
    var item = new LootItem(...itemLoot)
    this.entries.push( item )
    return item
  }
  empty(){
    this.table.pools[0].entries.push({
      type: "empty"
    })
    return this
  }
  toString(){
    return "loot_tables/" + this.name
  }
  toCmd(){
    return "loot spawn ~~~ loot " + this.name
  }
  generate(){
    var json = {...this.table}
    for( let entry of this.entries ){
      json.pools[0].entries.push( entry.jsonify() )
    }
    this.plugin.write( "data/" + this.toString() + ".json", JSON.stringify( json, 0, 2 ) )
  }
}

class LootPlugin extends ActivePlugin {
  constructor( ctx ){
    super( "Loot", ctx )
    this.loots = []
    ctx.LootTable = ( item, count ) => {
      var loot = new LootTable( item, count, this )
      this.loots.push( loot )
      return loot
    }
  }
  onGenerate(){
    this.loots.forEach((v) => v.generate())
  }
}

module.exports = LootPlugin
},{"../Plugin":13}],19:[function(require,module,exports){
var {ActivePlugin} = require( "../Plugin" )

class CraftingTable {
  constructor( id, output, recipe, count = 1, where = "crafting_table" ){
    this.id = id
    this.where = where
    this.recipe = recipe
    this.output = output
    this.count = count
  }
  has( item ){
    for( let key of Object.keys( this.recipe.key ) ){
      if( this.recipe.key[key] == item ) return true
    }
    return false
  }
  includes( item ){
    return has( item )
  }
  replace( item, item2 ){
    for( let key of Object.keys( this.recipe.key ) ){
      if( item == key ) (this.recipe.key[key] = item2.toString())
      if( this.recipe.key[key] == item ) (this.recipe.key[key] = item2.toString())
    }
    return this
  }
  source(){
    return {
      format_version: "1.12.2", "minecraft:recipe_shaped": {
        description: {
          identifier: this.id
        }, tags: [].concat(this.where),
        pattern: this.recipe.table,
        key: this.recipe.key,
        result: { item: this.output, count: this.count }
      }
    }
  }
}

class Recipe extends ActivePlugin {
  constructor( ctx ){
    super( "Recipe", ctx )
    this.ctx = ctx
    this.recipes = []
    ctx.Recipe = (...args) => this.craftingTable(...args)
  }
  onGenerate(){
    for( let recipe of this.recipes ){
      this.write( "data/recipes/" + this.subId(recipe.id) + ".json", JSON.stringify(recipe.source(),0,2) )
    }
  }
  craftingTable( item, table, count = 1, tag = "crafting_table" ){
    var recipe = {table: [ ["","",""], ["","",""], ["","",""] ], key: {}}, newTable = []
    if( Array.isArray( table ) ){
      var recipeSymbol = 10
      for( let itemIndex in table ){
        let mkey, item = table[itemIndex]
        if( item == null ){
          recipe.table[parseInt(itemIndex/3)][itemIndex%3] = " "
        } else if( (mkey = hasItem( recipe.key, item ))){
          recipe.table[parseInt(itemIndex/3)][itemIndex%3] = mkey
        } else {
          recipe.key[(mkey = recipeSymbol.toString(36))] = item.id ? item.id :
            item.getId ? item.getId() : item.toString()
          recipe.table[parseInt(itemIndex/3)][itemIndex%3] = mkey
          recipeSymbol += 1
        }
      }
      recipe.table.forEach((keys) => {
        if( keys.join( "" ) == "" ) return;
        newTable.push( keys.join( "" ) )
      })
      recipe.table = newTable
    } else {
      recipe = table
    }
    var table = new CraftingTable( this.ctx.namespace + ":recipe" + this.recipes.length, item.id ? item.id : item.getId ? item.getId() : item.toString(), recipe, count, tag)
    this.recipes.push( table )
    return table
    function hasItem( key, item ){
      for( let k of Object.keys(key) ){
        if( key[k] === item.id ? item.id :
          item.getId ? item.getId() : item.toString()
        ){
          return [k]
        }
      }
      return false
    }
  }
}

module.exports = Recipe
},{"../Plugin":13}],20:[function(require,module,exports){
module.exports={
  "weapon": {},
  "damage": 6,
  "max_stack_size": 1,
  "hand_equipped": true,
  "repairable": {
    "repair_items": [{
      "items": ["minecraft:diamond"],
      "repair_amount": 10
    }]
  },
  "enchantable": {
    "value": 10,
    "slot": "sword"
  }
}
},{}],21:[function(require,module,exports){
module.exports={
  "table": [ "x", "x", "y" ],
  "key": {
    "x": "minecraft:diamond",
    "y": "minecraft:stick"
  }
}
},{}],22:[function(require,module,exports){
module.exports={
  "weapon": {},
  "damage": 4,
  "max_stack_size": 1,
  "hand_equipped": true,
  "repairable": {
    "repair_items": [{
      "items": ["minecraft:gold_ingot"],
      "repair_amount": 10
    }]
  },
  "enchantable": {
    "value": 10,
    "slot": "sword"
  }
}
},{}],23:[function(require,module,exports){
module.exports={
  "table": [ "x", "x", "y" ],
  "key": {
    "x": "minecraft:gold_ingot",
    "y": "minecraft:stick"
  }
}
},{}],24:[function(require,module,exports){
module.exports={
  "weapon": {},
  "damage": 6,
  "max_stack_size": 1,
  "hand_equipped": true,
  "repairable": {
    "repair_items": [{
      "items": ["minecraft:iron_ingot"],
      "repair_amount": 10
    }]
  },
  "enchantable": {
    "value": 10,
    "slot": "sword"
  }
}
},{}],25:[function(require,module,exports){
module.exports={
  "table": [ "x", "x", "y" ],
  "key": {
    "x": "minecraft:iron_ingot",
    "y": "minecraft:stick"
  }
}
},{}],26:[function(require,module,exports){
var {ActivePlugin} = require( "../../Plugin" )

class VanillaReAchieveByLoveKogasa extends ActivePlugin {
  constructor( context ){
    super( "Vanilla", context )
    this.ctx = context
    context.Vanilla = {
      IronSword( extendMeta = false ){
        var json = require( "./IronSword.json" )
        var item = context.Item( "Iron Sword", json, false )
        item.bindRecipe( context.Recipe( item,
          require( "./IronSwordRecipe.json" )
        ))
        if( extendMeta ) item.setIcon( "iron_sword" )
        return item
      },
      GoldSword( extendMeta = false ){
        var json = require( "./GoldSword.json" )
        var item = context.Item( "Gold Sword", json, false )
        item.bindRecipe( context.Recipe( item,
          require( "./GoldSwordRecipe.json" )
        ))
        if( extendMeta ) item.setIcon( "iron_sword" )
        return item
      },
      DiamondSword( extendMeta = false ){
        var json = require( "./DiamondSword.json" )
        var item = context.Item( "Diamond Sword", json, false )
        item.bindRecipe( context.Recipe( item,
          require( "./DiamondSwordRecipe.json" )
        ))
        if( extendMeta ) item.setIcon( "iron_sword" )
        return item
      }
    }
  }
}

module.exports = VanillaReAchieveByLoveKogasa
},{"../../Plugin":13,"./DiamondSword.json":20,"./DiamondSwordRecipe.json":21,"./GoldSword.json":22,"./GoldSwordRecipe.json":23,"./IronSword.json":24,"./IronSwordRecipe.json":25}],27:[function(require,module,exports){
const Plugin_1 = require("../Plugin");
class lang {
    constructor(local, name) {
        this.local = local;
        this.name = name || undefined;
        this.data = {};
    }
    t(key, param) {
        this.data[key] = (param === null || param === void 0 ? void 0 : param.toString()) || '';
    }
}
module.exports = class I18n extends Plugin_1.ActivePlugin {
    constructor(ctx) {
        super('i18n', ctx);
        this.langs = {};
        this.customLangs = {};
    }
    generateLang(data) {
        let result = '';
        for (const key in data)
            if(typeof data[key] != "function") result += `${key}=${data[key]}\n`;
        return result;
    }
    new(local, isCustom = false, customName) {
        if (isCustom && !this.customLangs[local])
            this.customLangs[local] = new lang(local, customName);
        if (!this.langs[local])
            this.langs[local] = new lang(local);
        return isCustom ? this.customLangs[local] : this.langs[local];
    }
    listAll() {
        return Object.keys(this.langs);
    }
    listAllCustom() {
        return Object.keys(this.customLangs);
    }
    onGenerate() {
        console.log('Generating i18n files...');
        for (const _lang in this.langs)
            if( this.langs[_lang].data )
                this.write(`resources/texts/${_lang}.lang`, this.generateLang(this.langs[_lang].data));
        for (const _cstLang in this.customLangs)
            if( this.customLangs[_cstLang].data )
                this.write(`resources/texts/${_cstLang}.lang`, this.generateLang(this.customLangs[_cstLang].data));
        this.write('resources/texts/languages.json', JSON.stringify(this.listAllCustom()));
        this.write('resources/texts/language_names.json', JSON.stringify(this.listAllCustom().map(l => [l, this.customLangs[l].name || l])));
    }
};

},{"../Plugin":13}],28:[function(require,module,exports){
module.exports = function( id, icon, name, type = "items", components = {}, events = {}, format = "1.16.100" ){
  // 旧版Api === 屎
  var data = components
  data[ "minecraft:display_name" ] = {value: name}
  data[ "minecraft:icon" ] = {texture: icon}
  var eves = events
  function getJson(){
    return {
      "format_version": format,
      "minecraft:item": {
        description: {
          identifier: id,
          category: type
        },
        components: data,
        events: eves
      }
    }
  }
  function item(){
    return [{path: "data/items/" + id.split( ":" )[1] + ".json",
    json: getJson()}]
  }
  function get( key ){
    return data[ "minecraft:" + key ]
  }
  function getId(){
    return id
  }
  function getEvent( key ){
    return eves[key]
  }
  function getIcon(){
    return data[ "minecraft:icon" ].texture
  }
  function getName(){
    return data[ "minecraft:display_name" ].value
  }
  function setComponents( key, value ){
    data[ key ] = value
  }
  function set( key, value ){
    data[ "minecraft:" + key ] = value
  }
  function setName( value ){
    data[ "minecraft:display_name" ].value = value
  }
  function reId( id ){
    id = id
  }
  function setEvent( key, value ){
    eves[ key ] = value
  }
  /*function setRecipe( table, keys, count = 1, tag = "crafting_table" ){
    others.push( {
      path : "data/recipes/" + id.split( ":" )[1] + "_recipe.json",
      json : {
        "format_version": "1.12.2",
        "minecraft:recipe_shaped": {
          description: {
            identifier: id + "_recipe"
          },
          tags: Array.isArray( tag ) ? tag : [tag],
          pattern: table,
          key: keys,
          result: {
            item: id,
            count: count
          }
        }
      }
    })
  }*/
  return {json:item, setComponents, set, setEvent, get, getId, getEvent, toString: getId, setName, reId, getJson, bindRecipe( recipe ){ this.recipe = recipe }, extend( item ){
    var nitemc = {}
    for( let components of Object.keys((nitemc = item.getJson()["minecraft:item"].components)) ){
      if( !data[components] ) setComponents( components, nitemc[components] )
    }
    if( item.recipe ){
      item.recipe.output = getId()
      this.recipe = item.recipe
    }
    return this
  }}
}
},{}]},{},[4]);
